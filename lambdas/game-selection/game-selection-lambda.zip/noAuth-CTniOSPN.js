"use strict";
function extendedEncodeURIComponent(str) {
  return encodeURIComponent(str).replace(/[!'()*]/g, function(c) {
    return "%" + c.charCodeAt(0).toString(16).toUpperCase();
  });
}
class NoAuthSigner {
  async sign(httpRequest, identity, signingProperties) {
    return httpRequest;
  }
}
exports.NoAuthSigner = NoAuthSigner;
exports.extendedEncodeURIComponent = extendedEncodeURIComponent;
