"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const dev = require("./dev.js");
const require$$1 = require("fs");
const require$$0 = require("path");
function _interopNamespaceDefault(e) {
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const require$$1__namespace = /* @__PURE__ */ _interopNamespaceDefault(require$$1);
const require$$0__namespace = /* @__PURE__ */ _interopNamespaceDefault(require$$0);
dev.u();
var m = class extends dev.ur {
  constructor(t) {
    super(t), this.rootDir = require$$0__namespace.resolve(t), require$$1__namespace.existsSync(require$$0__namespace.join(this.rootDir)) || require$$1__namespace.mkdirSync(this.rootDir);
  }
  async init(t, e) {
    return this.pg = t, { emscriptenOpts: { ...e, preRun: [...e.preRun || [], (r) => {
      let c = r.FS.filesystems.NODEFS;
      r.FS.mkdir(dev.C), r.FS.mount(c, { root: this.rootDir }, dev.C);
    }] } };
  }
  async closeFs() {
    this.pg.Module.FS.quit();
  }
};
exports.NodeFS = m;
