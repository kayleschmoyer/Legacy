"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const dev = require("./dev.js");
dev.u();
var $ = "state.txt", G = "data", T = { DIR: 16384, FILE: 32768 }, H, v, F, M, y, b, m, x, P, D, S, n, C, O, k, w, f, I, W, j, L = class extends dev.cr {
  constructor(e, { initialPoolSize: t = 1e3, maintainedPoolSize: o = 100, debug: i = false } = {}) {
    super(e, { debug: i });
    dev.R(this, n);
    dev.R(this, H);
    dev.R(this, v);
    dev.R(this, F);
    dev.R(this, M);
    dev.R(this, y);
    dev.R(this, b, /* @__PURE__ */ new Map());
    dev.R(this, m, /* @__PURE__ */ new Map());
    dev.R(this, x, 0);
    dev.R(this, P, /* @__PURE__ */ new Map());
    dev.R(this, D, /* @__PURE__ */ new Map());
    this.lastCheckpoint = 0;
    this.checkpointInterval = 1e3 * 60;
    this.poolCounter = 0;
    dev.R(this, S, /* @__PURE__ */ new Set());
    this.initialPoolSize = t, this.maintainedPoolSize = o;
  }
  async init(e, t) {
    return await dev.T(this, n, C).call(this), super.init(e, t);
  }
  async syncToFs(e = false) {
    await this.maybeCheckpointState(), await this.maintainPool(), e || this.flush();
  }
  async closeFs() {
    for (let e of dev.h(this, m).values()) e.close();
    dev.h(this, y).flush(), dev.h(this, y).close(), this.pg.Module.FS.quit();
  }
  async maintainPool(e) {
    e = e || this.maintainedPoolSize;
    let t = e - this.state.pool.length, o = [];
    for (let i = 0; i < t; i++) o.push(new Promise(async (c) => {
      ++this.poolCounter;
      let a = `${(Date.now() - 1704063600).toString(16).padStart(8, "0")}-${this.poolCounter.toString(16).padStart(8, "0")}`, h = await dev.h(this, F).getFileHandle(a, { create: true }), d = await h.createSyncAccessHandle();
      dev.h(this, b).set(a, h), dev.h(this, m).set(a, d), dev.T(this, n, k).call(this, { opp: "createPoolFile", args: [a] }), this.state.pool.push(a), c();
    }));
    for (let i = 0; i > t; i--) o.push(new Promise(async (c) => {
      let a = this.state.pool.pop();
      dev.T(this, n, k).call(this, { opp: "deletePoolFile", args: [a] });
      let h = dev.h(this, b).get(a);
      dev.h(this, m).get(a)?.close(), await dev.h(this, F).removeEntry(h.name), dev.h(this, b).delete(a), dev.h(this, m).delete(a), c();
    }));
    await Promise.all(o);
  }
  _createPoolFileState(e) {
    this.state.pool.push(e);
  }
  _deletePoolFileState(e) {
    let t = this.state.pool.indexOf(e);
    t > -1 && this.state.pool.splice(t, 1);
  }
  async maybeCheckpointState() {
    Date.now() - this.lastCheckpoint > this.checkpointInterval && await this.checkpointState();
  }
  async checkpointState() {
    let e = new TextEncoder().encode(JSON.stringify(this.state));
    dev.h(this, y).truncate(0), dev.h(this, y).write(e, { at: 0 }), dev.h(this, y).flush(), this.lastCheckpoint = Date.now();
  }
  flush() {
    for (let e of dev.h(this, S)) try {
      e.flush();
    } catch {
    }
    dev.h(this, S).clear();
  }
  chmod(e, t) {
    dev.T(this, n, O).call(this, { opp: "chmod", args: [e, t] }, () => {
      this._chmodState(e, t);
    });
  }
  _chmodState(e, t) {
    let o = dev.T(this, n, f).call(this, e);
    o.mode = t;
  }
  close(e) {
    let t = dev.T(this, n, I).call(this, e);
    dev.h(this, P).delete(e), dev.h(this, D).delete(t);
  }
  fstat(e) {
    let t = dev.T(this, n, I).call(this, e);
    return this.lstat(t);
  }
  lstat(e) {
    let t = dev.T(this, n, f).call(this, e), o = t.type === "file" ? dev.h(this, m).get(t.backingFilename).getSize() : 0, i = 4096;
    return { dev: 0, ino: 0, mode: t.mode, nlink: 1, uid: 0, gid: 0, rdev: 0, size: o, blksize: i, blocks: Math.ceil(o / i), atime: t.lastModified, mtime: t.lastModified, ctime: t.lastModified };
  }
  mkdir(e, t) {
    dev.T(this, n, O).call(this, { opp: "mkdir", args: [e, t] }, () => {
      this._mkdirState(e, t);
    });
  }
  _mkdirState(e, t) {
    let o = dev.T(this, n, w).call(this, e), i = o.pop(), c = [], a = this.state.root;
    for (let d of o) {
      if (c.push(e), !Object.prototype.hasOwnProperty.call(a.children, d)) if (t?.recursive) this.mkdir(c.join("/"));
      else throw new p("ENOENT", "No such file or directory");
      if (a.children[d].type !== "directory") throw new p("ENOTDIR", "Not a directory");
      a = a.children[d];
    }
    if (Object.prototype.hasOwnProperty.call(a.children, i)) throw new p("EEXIST", "File exists");
    let h = { type: "directory", lastModified: Date.now(), mode: t?.mode || T.DIR, children: {} };
    a.children[i] = h;
  }
  open(e, t, o) {
    if (dev.T(this, n, f).call(this, e).type !== "file") throw new p("EISDIR", "Is a directory");
    let c = dev.T(this, n, W).call(this);
    return dev.h(this, P).set(c, e), dev.h(this, D).set(e, c), c;
  }
  readdir(e) {
    let t = dev.T(this, n, f).call(this, e);
    if (t.type !== "directory") throw new p("ENOTDIR", "Not a directory");
    return Object.keys(t.children);
  }
  read(e, t, o, i, c) {
    let a = dev.T(this, n, I).call(this, e), h = dev.T(this, n, f).call(this, a);
    if (h.type !== "file") throw new p("EISDIR", "Is a directory");
    return dev.h(this, m).get(h.backingFilename).read(new Uint8Array(t.buffer, o, i), { at: c });
  }
  rename(e, t) {
    dev.T(this, n, O).call(this, { opp: "rename", args: [e, t] }, () => {
      this._renameState(e, t, true);
    });
  }
  _renameState(e, t, o = false) {
    let i = dev.T(this, n, w).call(this, e), c = i.pop(), a = dev.T(this, n, f).call(this, i.join("/"));
    if (!Object.prototype.hasOwnProperty.call(a.children, c)) throw new p("ENOENT", "No such file or directory");
    let h = dev.T(this, n, w).call(this, t), d = h.pop(), l = dev.T(this, n, f).call(this, h.join("/"));
    if (o && Object.prototype.hasOwnProperty.call(l.children, d)) {
      let u = l.children[d];
      dev.h(this, m).get(u.backingFilename).truncate(0), this.state.pool.push(u.backingFilename);
    }
    l.children[d] = a.children[c], delete a.children[c];
  }
  rmdir(e) {
    dev.T(this, n, O).call(this, { opp: "rmdir", args: [e] }, () => {
      this._rmdirState(e);
    });
  }
  _rmdirState(e) {
    let t = dev.T(this, n, w).call(this, e), o = t.pop(), i = dev.T(this, n, f).call(this, t.join("/"));
    if (!Object.prototype.hasOwnProperty.call(i.children, o)) throw new p("ENOENT", "No such file or directory");
    let c = i.children[o];
    if (c.type !== "directory") throw new p("ENOTDIR", "Not a directory");
    if (Object.keys(c.children).length > 0) throw new p("ENOTEMPTY", "Directory not empty");
    delete i.children[o];
  }
  truncate(e, t = 0) {
    let o = dev.T(this, n, f).call(this, e);
    if (o.type !== "file") throw new p("EISDIR", "Is a directory");
    let i = dev.h(this, m).get(o.backingFilename);
    if (!i) throw new p("ENOENT", "No such file or directory");
    i.truncate(t), dev.h(this, S).add(i);
  }
  unlink(e) {
    dev.T(this, n, O).call(this, { opp: "unlink", args: [e] }, () => {
      this._unlinkState(e, true);
    });
  }
  _unlinkState(e, t = false) {
    let o = dev.T(this, n, w).call(this, e), i = o.pop(), c = dev.T(this, n, f).call(this, o.join("/"));
    if (!Object.prototype.hasOwnProperty.call(c.children, i)) throw new p("ENOENT", "No such file or directory");
    let a = c.children[i];
    if (a.type !== "file") throw new p("EISDIR", "Is a directory");
    if (delete c.children[i], t) {
      let h = dev.h(this, m).get(a.backingFilename);
      h?.truncate(0), dev.h(this, S).add(h), dev.h(this, D).has(e) && (dev.h(this, P).delete(dev.h(this, D).get(e)), dev.h(this, D).delete(e));
    }
    this.state.pool.push(a.backingFilename);
  }
  utimes(e, t, o) {
    dev.T(this, n, O).call(this, { opp: "utimes", args: [e, t, o] }, () => {
      this._utimesState(e, t, o);
    });
  }
  _utimesState(e, t, o) {
    let i = dev.T(this, n, f).call(this, e);
    i.lastModified = o;
  }
  writeFile(e, t, o) {
    let i = dev.T(this, n, w).call(this, e), c = i.pop(), a = dev.T(this, n, f).call(this, i.join("/"));
    if (Object.prototype.hasOwnProperty.call(a.children, c)) {
      let l = a.children[c];
      l.lastModified = Date.now(), dev.T(this, n, k).call(this, { opp: "setLastModified", args: [e, l.lastModified] });
    } else {
      if (this.state.pool.length === 0) throw new Error("No more file handles available in the pool");
      let l = { type: "file", lastModified: Date.now(), mode: o?.mode || T.FILE, backingFilename: this.state.pool.pop() };
      a.children[c] = l, dev.T(this, n, k).call(this, { opp: "createFileNode", args: [e, l] });
    }
    let h = a.children[c], d = dev.h(this, m).get(h.backingFilename);
    t.length > 0 && (d.write(typeof t == "string" ? new TextEncoder().encode(t) : new Uint8Array(t), { at: 0 }), e.startsWith("/pg_wal") && dev.h(this, S).add(d));
  }
  _createFileNodeState(e, t) {
    let o = dev.T(this, n, w).call(this, e), i = o.pop(), c = dev.T(this, n, f).call(this, o.join("/"));
    c.children[i] = t;
    let a = this.state.pool.indexOf(t.backingFilename);
    return a > -1 && this.state.pool.splice(a, 1), t;
  }
  _setLastModifiedState(e, t) {
    let o = dev.T(this, n, f).call(this, e);
    o.lastModified = t;
  }
  write(e, t, o, i, c) {
    let a = dev.T(this, n, I).call(this, e), h = dev.T(this, n, f).call(this, a);
    if (h.type !== "file") throw new p("EISDIR", "Is a directory");
    let d = dev.h(this, m).get(h.backingFilename);
    if (!d) throw new p("EBADF", "Bad file descriptor");
    let l = d.write(new Uint8Array(t, o, i), { at: c });
    return a.startsWith("/pg_wal") && dev.h(this, S).add(d), l;
  }
};
H = /* @__PURE__ */ new WeakMap(), v = /* @__PURE__ */ new WeakMap(), F = /* @__PURE__ */ new WeakMap(), M = /* @__PURE__ */ new WeakMap(), y = /* @__PURE__ */ new WeakMap(), b = /* @__PURE__ */ new WeakMap(), m = /* @__PURE__ */ new WeakMap(), x = /* @__PURE__ */ new WeakMap(), P = /* @__PURE__ */ new WeakMap(), D = /* @__PURE__ */ new WeakMap(), S = /* @__PURE__ */ new WeakMap(), n = /* @__PURE__ */ new WeakSet(), C = async function() {
  dev.x(this, H, await navigator.storage.getDirectory()), dev.x(this, v, await dev.T(this, n, j).call(this, this.dataDir, { create: true })), dev.x(this, F, await dev.T(this, n, j).call(this, G, { from: dev.h(this, v), create: true })), dev.x(this, M, await dev.h(this, v).getFileHandle($, { create: true })), dev.x(this, y, await dev.h(this, M).createSyncAccessHandle());
  let e = new ArrayBuffer(dev.h(this, y).getSize());
  dev.h(this, y).read(e, { at: 0 });
  let t, o = new TextDecoder().decode(e).split(`
`), i = false;
  try {
    t = JSON.parse(o[0]);
  } catch {
    t = { root: { type: "directory", lastModified: Date.now(), mode: T.DIR, children: {} }, pool: [] }, dev.h(this, y).truncate(0), dev.h(this, y).write(new TextEncoder().encode(JSON.stringify(t)), { at: 0 }), i = true;
  }
  this.state = t;
  let c = o.slice(1).filter(Boolean).map((l) => JSON.parse(l));
  for (let l of c) {
    let u = `_${l.opp}State`;
    if (typeof this[u] == "function") try {
      this[u].bind(this)(...l.args);
    } catch (N) {
      console.warn("Error applying OPFS AHP WAL entry", l, N);
    }
  }
  let a = [], h = async (l) => {
    if (l.type === "file") try {
      let u = await dev.h(this, F).getFileHandle(l.backingFilename), N = await u.createSyncAccessHandle();
      dev.h(this, b).set(l.backingFilename, u), dev.h(this, m).set(l.backingFilename, N);
    } catch (u) {
      console.error("Error opening file handle for node", l, u);
    }
    else for (let u of Object.values(l.children)) a.push(h(u));
  };
  await h(this.state.root);
  let d = [];
  for (let l of this.state.pool) d.push(new Promise(async (u) => {
    dev.h(this, b).has(l) && console.warn("File handle already exists for pool file", l);
    let N = await dev.h(this, F).getFileHandle(l), U = await N.createSyncAccessHandle();
    dev.h(this, b).set(l, N), dev.h(this, m).set(l, U), u();
  }));
  await Promise.all([...a, ...d]), await this.maintainPool(i ? this.initialPoolSize : this.maintainedPoolSize);
}, O = function(e, t) {
  let o = dev.T(this, n, k).call(this, e);
  try {
    t();
  } catch (i) {
    throw dev.h(this, y).truncate(o), i;
  }
}, k = function(e) {
  let t = JSON.stringify(e), o = new TextEncoder().encode(`
${t}`), i = dev.h(this, y).getSize();
  return dev.h(this, y).write(o, { at: i }), dev.h(this, S).add(dev.h(this, y)), i;
}, w = function(e) {
  return e.split("/").filter(Boolean);
}, f = function(e, t) {
  let o = dev.T(this, n, w).call(this, e), i = t || this.state.root;
  for (let c of o) {
    if (i.type !== "directory") throw new p("ENOTDIR", "Not a directory");
    if (!Object.prototype.hasOwnProperty.call(i.children, c)) throw new p("ENOENT", "No such file or directory");
    i = i.children[c];
  }
  return i;
}, I = function(e) {
  let t = dev.h(this, P).get(e);
  if (!t) throw new p("EBADF", "Bad file descriptor");
  return t;
}, W = function() {
  let e = ++dev.U(this, x)._;
  for (; dev.h(this, P).has(e); ) dev.U(this, x)._++;
  return e;
}, j = async function(e, t) {
  let o = dev.T(this, n, w).call(this, e), i = t?.from || dev.h(this, H);
  for (let c of o) i = await i.getDirectoryHandle(c, { create: t?.create });
  return i;
};
var p = class extends Error {
  constructor(A, e) {
    super(e), typeof A == "number" ? this.code = A : typeof A == "string" && (this.code = dev.pr[A]);
  }
};
exports.OpfsAhpFS = L;
