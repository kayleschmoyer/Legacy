"use strict";
const packageVersion = "4.12.2";
exports.packageVersion = packageVersion;
