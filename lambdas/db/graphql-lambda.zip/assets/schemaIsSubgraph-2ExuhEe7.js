"use strict";
const index = require("../index.js");
function schemaIsSubgraph(schema) {
  const serviceType = schema.getType("_Service");
  if (!index.isObjectType(serviceType)) {
    return false;
  }
  const sdlField = serviceType.getFields().sdl;
  if (!sdlField) {
    return false;
  }
  let sdlFieldType = sdlField.type;
  if (index.isNonNullType(sdlFieldType)) {
    sdlFieldType = sdlFieldType.ofType;
  }
  if (!index.isScalarType(sdlFieldType)) {
    return false;
  }
  return sdlFieldType.name == "String";
}
exports.schemaIsSubgraph = schemaIsSubgraph;
