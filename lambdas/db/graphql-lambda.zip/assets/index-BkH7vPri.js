"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const traceTreeBuilder = require("./traceTreeBuilder-DN8I-AA6.js");
const index = require("../index.js");
const schemaIsSubgraph = require("./schemaIsSubgraph-2ExuhEe7.js");
require("crypto");
require("buffer");
require("events");
require("stream");
require("http");
require("url");
require("punycode");
require("https");
require("zlib");
require("os");
require("process");
require("path");
require("fs");
require("util");
require("dns");
require("net");
require("tls");
require("string_decoder");
function ApolloServerPluginInlineTrace(options = /* @__PURE__ */ Object.create(null)) {
  let enabled = options.__onlyIfSchemaIsSubgraph ? null : true;
  return index.internalPlugin({
    __internal_plugin_id__: "InlineTrace",
    __is_disabled_plugin__: false,
    async serverWillStart({ schema, logger }) {
      if (enabled === null) {
        enabled = schemaIsSubgraph.schemaIsSubgraph(schema);
        if (enabled) {
          logger.info("Enabling inline tracing for this subgraph. To disable, use ApolloServerPluginInlineTraceDisabled.");
        }
      }
    },
    async requestDidStart({ request: { http }, metrics }) {
      if (!enabled) {
        return;
      }
      const treeBuilder = new traceTreeBuilder.TraceTreeBuilder({
        maskedBy: "ApolloServerPluginInlineTrace",
        sendErrors: options.includeErrors
      });
      if (http?.headers.get("apollo-federation-include-trace") !== "ftv1") {
        return;
      }
      if (metrics.captureTraces === false) {
        return;
      }
      metrics.captureTraces = true;
      treeBuilder.startTiming();
      return {
        async executionDidStart() {
          return {
            willResolveField({ info }) {
              return treeBuilder.willResolveField(info);
            }
          };
        },
        async didEncounterErrors({ errors }) {
          treeBuilder.didEncounterErrors(errors);
        },
        async willSendResponse({ response }) {
          treeBuilder.stopTiming();
          if (response.body.kind === "incremental") {
            return;
          }
          if (metrics.queryPlanTrace) {
            treeBuilder.trace.queryPlan = metrics.queryPlanTrace;
          }
          const encodedUint8Array = traceTreeBuilder.Trace.encode(treeBuilder.trace).finish();
          const encodedBuffer = Buffer.from(encodedUint8Array, encodedUint8Array.byteOffset, encodedUint8Array.byteLength);
          const extensions = response.body.singleResult.extensions || (response.body.singleResult.extensions = /* @__PURE__ */ Object.create(null));
          if (typeof extensions.ftv1 !== "undefined") {
            throw new Error("The `ftv1` extension was already present.");
          }
          extensions.ftv1 = encodedBuffer.toString("base64");
        }
      };
    }
  });
}
exports.ApolloServerPluginInlineTrace = ApolloServerPluginInlineTrace;
