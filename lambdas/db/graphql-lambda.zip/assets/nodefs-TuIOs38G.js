"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const index = require("../index.js");
const s = require("fs");
const require$$0 = require("path");
require("crypto");
require("buffer");
require("events");
require("stream");
require("http");
require("url");
require("punycode");
require("https");
require("zlib");
require("os");
require("process");
require("util");
require("dns");
require("net");
require("tls");
require("string_decoder");
function _interopNamespaceDefault(e) {
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const s__namespace = /* @__PURE__ */ _interopNamespaceDefault(s);
const require$$0__namespace = /* @__PURE__ */ _interopNamespaceDefault(require$$0);
index.u();
var m = class extends index.ur {
  constructor(t) {
    super(t), this.rootDir = require$$0__namespace.resolve(t), s__namespace.existsSync(require$$0__namespace.join(this.rootDir)) || s__namespace.mkdirSync(this.rootDir);
  }
  async init(t, e) {
    return this.pg = t, { emscriptenOpts: { ...e, preRun: [...e.preRun || [], (r) => {
      let c = r.FS.filesystems.NODEFS;
      r.FS.mkdir(index.C), r.FS.mount(c, { root: this.rootDir }, index.C);
    }] } };
  }
  async closeFs() {
    this.pg.Module.FS.quit();
  }
};
exports.NodeFS = m;
