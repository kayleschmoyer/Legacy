"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const os = require("os");
const index = require("../index.js");
const packageVersion = require("./packageVersion-FhzH5XqK.js");
const schemaIsSubgraph = require("./schemaIsSubgraph-2ExuhEe7.js");
require("crypto");
require("buffer");
require("events");
require("stream");
require("http");
require("url");
require("punycode");
require("https");
require("zlib");
require("process");
require("path");
require("fs");
require("util");
require("dns");
require("net");
require("tls");
require("string_decoder");
const schemaReportGql = `#graphql
  mutation SchemaReport($report: SchemaReport!, $coreSchema: String) {
    reportSchema(report: $report, coreSchema: $coreSchema) {
      __typename
      ... on ReportSchemaError {
        message
        code
      }
      ... on ReportSchemaResponse {
        inSeconds
        withCoreSchema
      }
    }
  }
`;
class SchemaReporter {
  constructor(options) {
    this.headers = {
      "Content-Type": "application/json",
      "x-api-key": options.apiKey,
      "apollographql-client-name": "ApolloServerPluginSchemaReporting",
      "apollographql-client-version": packageVersion.packageVersion
    };
    this.endpointUrl = options.endpointUrl || "https://schema-reporting.api.apollographql.com/api/graphql";
    this.schemaReport = options.schemaReport;
    this.coreSchema = options.coreSchema;
    this.isStopped = false;
    this.logger = options.logger;
    this.initialReportingDelayInMs = options.initialReportingDelayInMs;
    this.fallbackReportingDelayInMs = options.fallbackReportingDelayInMs;
    this.fetcher = options.fetcher ?? index.fetch;
  }
  stopped() {
    return this.isStopped;
  }
  start() {
    this.pollTimer = setTimeout(() => this.sendOneReportAndScheduleNext(false), this.initialReportingDelayInMs);
  }
  stop() {
    this.isStopped = true;
    if (this.pollTimer) {
      clearTimeout(this.pollTimer);
      this.pollTimer = void 0;
    }
  }
  async sendOneReportAndScheduleNext(sendNextWithCoreSchema) {
    this.pollTimer = void 0;
    if (this.stopped())
      return;
    try {
      const result = await this.reportSchema(sendNextWithCoreSchema);
      if (!result) {
        return;
      }
      if (!this.stopped()) {
        this.pollTimer = setTimeout(() => this.sendOneReportAndScheduleNext(result.withCoreSchema), result.inSeconds * 1e3);
      }
      return;
    } catch (error) {
      this.logger.error(`Error reporting server info to Apollo during schema reporting: ${error}`);
      if (!this.stopped()) {
        this.pollTimer = setTimeout(() => this.sendOneReportAndScheduleNext(false), this.fallbackReportingDelayInMs);
      }
    }
  }
  async reportSchema(withCoreSchema) {
    const { data, errors } = await this.apolloQuery({
      report: this.schemaReport,
      coreSchema: withCoreSchema ? this.coreSchema : null
    });
    if (errors) {
      throw new Error(errors.map((x) => x.message).join("\n"));
    }
    function msgForUnexpectedResponse(data2) {
      return [
        "Unexpected response shape from Apollo when",
        "reporting schema. If this continues, please reach",
        "out to support@apollographql.com.",
        "Received response:",
        JSON.stringify(data2)
      ].join(" ");
    }
    if (!data || !data.reportSchema) {
      throw new Error(msgForUnexpectedResponse(data));
    }
    if (data.reportSchema.__typename === "ReportSchemaResponse") {
      return data.reportSchema;
    } else if (data.reportSchema.__typename === "ReportSchemaError") {
      this.logger.error([
        "Received input validation error from Apollo:",
        data.reportSchema.message,
        "Stopping reporting. Please fix the input errors."
      ].join(" "));
      this.stop();
      return null;
    }
    throw new Error(msgForUnexpectedResponse(data));
  }
  async apolloQuery(variables) {
    const request = {
      query: schemaReportGql,
      variables
    };
    const httpResponse = await this.fetcher(this.endpointUrl, {
      method: "POST",
      headers: this.headers,
      body: JSON.stringify(request)
    });
    if (!httpResponse.ok) {
      throw new Error([
        `An unexpected HTTP status code (${httpResponse.status}) was`,
        "encountered during schema reporting."
      ].join(" "));
    }
    try {
      return await httpResponse.json();
    } catch (error) {
      throw new Error([
        "Couldn't report schema to Apollo.",
        "Parsing response as JSON failed.",
        "If this continues please reach out to support@apollographql.com",
        error
      ].join(" "));
    }
  }
}
function ApolloServerPluginSchemaReporting({ initialDelayMaxMs, overrideReportedSchema, endpointUrl, fetcher } = /* @__PURE__ */ Object.create(null)) {
  const bootId = index.v4();
  return index.internalPlugin({
    __internal_plugin_id__: "SchemaReporting",
    __is_disabled_plugin__: false,
    async serverWillStart({ apollo, schema, logger }) {
      const { key, graphRef } = apollo;
      if (!key) {
        throw Error("To use ApolloServerPluginSchemaReporting, you must provide an Apollo API key, via the APOLLO_KEY environment variable or via `new ApolloServer({apollo: {key})`");
      }
      if (!graphRef) {
        throw Error("To use ApolloServerPluginSchemaReporting, you must provide your graph ref (eg, 'my-graph-id@my-graph-variant'). Try setting the APOLLO_GRAPH_REF environment variable or passing `new ApolloServer({apollo: {graphRef}})`.");
      }
      if (overrideReportedSchema) {
        try {
          const validationErrors = index.validateSchema(index.buildSchema(overrideReportedSchema, { noLocation: true }));
          if (validationErrors.length) {
            throw new Error(validationErrors.map((error) => error.message).join("\n"));
          }
        } catch (err) {
          throw new Error(`The schema provided to overrideReportedSchema failed to parse or validate: ${err.message}`);
        }
      }
      if (schemaIsSubgraph.schemaIsSubgraph(schema)) {
        throw Error([
          "Schema reporting is not yet compatible with Apollo Federation subgraphs.",
          "If you're interested in using schema reporting with subgraphs,",
          "please contact Apollo support. To set up managed federation, see",
          "https://go.apollo.dev/s/managed-federation"
        ].join(" "));
      }
      if (endpointUrl !== void 0) {
        logger.info(`Apollo schema reporting: schema reporting URL override: ${endpointUrl}`);
      }
      const baseSchemaReport = {
        bootId,
        graphRef,
        platform: process.env.APOLLO_SERVER_PLATFORM || "local",
        runtimeVersion: `node ${process.version}`,
        userVersion: process.env.APOLLO_SERVER_USER_VERSION,
        serverId: process.env.APOLLO_SERVER_ID || process.env.HOSTNAME || os.hostname(),
        libraryVersion: `@apollo/server@${packageVersion.packageVersion}`
      };
      let currentSchemaReporter;
      return {
        schemaDidLoadOrUpdate({ apiSchema, coreSupergraphSdl }) {
          if (overrideReportedSchema !== void 0) {
            if (currentSchemaReporter) {
              return;
            } else {
              logger.info("Apollo schema reporting: schema to report has been overridden");
            }
          }
          const coreSchema = overrideReportedSchema ?? coreSupergraphSdl ?? index.printSchema(apiSchema);
          const coreSchemaHash = index.computeCoreSchemaHash(coreSchema);
          const schemaReport = {
            ...baseSchemaReport,
            coreSchemaHash
          };
          currentSchemaReporter?.stop();
          currentSchemaReporter = new SchemaReporter({
            schemaReport,
            coreSchema,
            apiKey: key,
            endpointUrl,
            logger,
            initialReportingDelayInMs: Math.floor(Math.random() * (initialDelayMaxMs ?? 1e4)),
            fallbackReportingDelayInMs: 2e4,
            fetcher
          });
          currentSchemaReporter.start();
          logger.info(`Apollo schema reporting: reporting a new schema to Studio! See your graph at https://studio.apollographql.com/graph/${encodeURI(graphRef)}/ with server info ${JSON.stringify(schemaReport)}`);
        },
        async serverWillStop() {
          currentSchemaReporter?.stop();
        }
      };
    }
  });
}
exports.ApolloServerPluginSchemaReporting = ApolloServerPluginSchemaReporting;
