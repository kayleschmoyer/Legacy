"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const index = require("../index.js");
const index$1 = require("./index-Bvz5b4Y-.js");
require("crypto");
require("buffer");
require("events");
require("stream");
require("http");
require("url");
require("punycode");
require("https");
require("zlib");
require("os");
require("process");
require("path");
require("fs");
require("util");
require("dns");
require("net");
require("tls");
require("string_decoder");
function ApolloServerPluginCacheControl(options = /* @__PURE__ */ Object.create(null)) {
  let typeAnnotationCache;
  let fieldAnnotationCache;
  return index.internalPlugin({
    __internal_plugin_id__: "CacheControl",
    __is_disabled_plugin__: false,
    async serverWillStart({ schema }) {
      typeAnnotationCache = new index$1.LRUCache({
        max: Object.values(schema.getTypeMap()).filter(index.isCompositeType).length
      });
      fieldAnnotationCache = new index$1.LRUCache({
        max: Object.values(schema.getTypeMap()).filter(index.isObjectType).flatMap((t) => Object.values(t.getFields())).length + Object.values(schema.getTypeMap()).filter(index.isInterfaceType).flatMap((t) => Object.values(t.getFields())).length
      });
      return void 0;
    },
    async requestDidStart(requestContext) {
      function memoizedCacheAnnotationFromType(t) {
        const existing = typeAnnotationCache.get(t);
        if (existing) {
          return existing;
        }
        const annotation = cacheAnnotationFromType(t);
        typeAnnotationCache.set(t, annotation);
        return annotation;
      }
      function memoizedCacheAnnotationFromField(field) {
        const existing = fieldAnnotationCache.get(field);
        if (existing) {
          return existing;
        }
        const annotation = cacheAnnotationFromField(field);
        fieldAnnotationCache.set(field, annotation);
        return annotation;
      }
      const defaultMaxAge = options.defaultMaxAge ?? 0;
      const calculateHttpHeaders = options.calculateHttpHeaders ?? true;
      const { __testing__cacheHints } = options;
      return {
        async executionDidStart() {
          if (isRestricted(requestContext.overallCachePolicy)) {
            const fakeFieldPolicy = index.newCachePolicy();
            return {
              willResolveField({ info }) {
                info.cacheControl = {
                  setCacheHint: (dynamicHint) => {
                    fakeFieldPolicy.replace(dynamicHint);
                  },
                  cacheHint: fakeFieldPolicy,
                  cacheHintFromType: memoizedCacheAnnotationFromType
                };
              }
            };
          }
          return {
            willResolveField({ info }) {
              const fieldPolicy = index.newCachePolicy();
              let inheritMaxAge = false;
              const targetType = index.getNamedType(info.returnType);
              if (index.isCompositeType(targetType)) {
                const typeAnnotation = memoizedCacheAnnotationFromType(targetType);
                fieldPolicy.replace(typeAnnotation);
                inheritMaxAge = !!typeAnnotation.inheritMaxAge;
              }
              const fieldAnnotation = memoizedCacheAnnotationFromField(info.parentType.getFields()[info.fieldName]);
              if (fieldAnnotation.inheritMaxAge && fieldPolicy.maxAge === void 0) {
                inheritMaxAge = true;
                if (fieldAnnotation.scope) {
                  fieldPolicy.replace({ scope: fieldAnnotation.scope });
                }
              } else {
                fieldPolicy.replace(fieldAnnotation);
              }
              info.cacheControl = {
                setCacheHint: (dynamicHint) => {
                  fieldPolicy.replace(dynamicHint);
                },
                cacheHint: fieldPolicy,
                cacheHintFromType: memoizedCacheAnnotationFromType
              };
              return () => {
                if (fieldPolicy.maxAge === void 0 && (index.isCompositeType(targetType) && !inheritMaxAge || !info.path.prev)) {
                  fieldPolicy.restrict({ maxAge: defaultMaxAge });
                }
                if (__testing__cacheHints && isRestricted(fieldPolicy)) {
                  const path = index.pathToArray(info.path).join(".");
                  if (__testing__cacheHints.has(path)) {
                    throw Error("shouldn't happen: addHint should only be called once per path");
                  }
                  __testing__cacheHints.set(path, {
                    maxAge: fieldPolicy.maxAge,
                    scope: fieldPolicy.scope
                  });
                }
                requestContext.overallCachePolicy.restrict(fieldPolicy);
              };
            }
          };
        },
        async willSendResponse(requestContext2) {
          if (!calculateHttpHeaders) {
            return;
          }
          const { response, overallCachePolicy } = requestContext2;
          const existingCacheControlHeader = parseExistingCacheControlHeader(response.http.headers.get("cache-control"));
          if (existingCacheControlHeader.kind === "unparsable") {
            return;
          }
          const cachePolicy = index.newCachePolicy();
          cachePolicy.replace(overallCachePolicy);
          if (existingCacheControlHeader.kind === "parsable-and-cacheable") {
            cachePolicy.restrict(existingCacheControlHeader.hint);
          }
          const policyIfCacheable = cachePolicy.policyIfCacheable();
          if (policyIfCacheable && existingCacheControlHeader.kind !== "uncacheable" && response.body.kind === "single" && !response.body.singleResult.errors) {
            response.http.headers.set("cache-control", `max-age=${policyIfCacheable.maxAge}, ${policyIfCacheable.scope.toLowerCase()}`);
          } else if (calculateHttpHeaders !== "if-cacheable") {
            response.http.headers.set("cache-control", CACHE_CONTROL_HEADER_UNCACHEABLE);
          }
        }
      };
    }
  });
}
const CACHE_CONTROL_HEADER_CACHEABLE_REGEXP = /^max-age=(\d+), (public|private)$/;
const CACHE_CONTROL_HEADER_UNCACHEABLE = "no-store";
function parseExistingCacheControlHeader(header) {
  if (!header) {
    return { kind: "no-header" };
  }
  if (header === CACHE_CONTROL_HEADER_UNCACHEABLE) {
    return { kind: "uncacheable" };
  }
  const match = CACHE_CONTROL_HEADER_CACHEABLE_REGEXP.exec(header);
  if (!match) {
    return { kind: "unparsable" };
  }
  return {
    kind: "parsable-and-cacheable",
    hint: {
      maxAge: +match[1],
      scope: match[2] === "public" ? "PUBLIC" : "PRIVATE"
    }
  };
}
function cacheAnnotationFromDirectives(directives) {
  if (!directives)
    return void 0;
  const cacheControlDirective = directives.find((directive) => directive.name.value === "cacheControl");
  if (!cacheControlDirective)
    return void 0;
  if (!cacheControlDirective.arguments)
    return void 0;
  const maxAgeArgument = cacheControlDirective.arguments.find((argument) => argument.name.value === "maxAge");
  const scopeArgument = cacheControlDirective.arguments.find((argument) => argument.name.value === "scope");
  const inheritMaxAgeArgument = cacheControlDirective.arguments.find((argument) => argument.name.value === "inheritMaxAge");
  const scopeString = scopeArgument?.value?.kind === "EnumValue" ? scopeArgument.value.value : void 0;
  const scope = scopeString === "PUBLIC" || scopeString === "PRIVATE" ? scopeString : void 0;
  if (inheritMaxAgeArgument?.value?.kind === "BooleanValue" && inheritMaxAgeArgument.value.value) {
    return { inheritMaxAge: true, scope };
  }
  return {
    maxAge: maxAgeArgument?.value?.kind === "IntValue" ? parseInt(maxAgeArgument.value.value) : void 0,
    scope
  };
}
function cacheAnnotationFromType(t) {
  if (t.astNode) {
    const hint = cacheAnnotationFromDirectives(t.astNode.directives);
    if (hint) {
      return hint;
    }
  }
  if (t.extensionASTNodes) {
    for (const node of t.extensionASTNodes) {
      const hint = cacheAnnotationFromDirectives(node.directives);
      if (hint) {
        return hint;
      }
    }
  }
  return {};
}
function cacheAnnotationFromField(field) {
  if (field.astNode) {
    const hint = cacheAnnotationFromDirectives(field.astNode.directives);
    if (hint) {
      return hint;
    }
  }
  return {};
}
function isRestricted(hint) {
  return hint.maxAge !== void 0 || hint.scope !== void 0;
}
exports.ApolloServerPluginCacheControl = ApolloServerPluginCacheControl;
