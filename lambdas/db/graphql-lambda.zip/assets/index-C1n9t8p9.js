"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const index = require("../index.js");
require("crypto");
require("buffer");
require("events");
require("stream");
require("http");
require("url");
require("punycode");
require("https");
require("zlib");
require("os");
require("process");
require("path");
require("fs");
require("util");
require("dns");
require("net");
require("tls");
require("string_decoder");
function ApolloServerPluginDisableSuggestions() {
  return index.internalPlugin({
    __internal_plugin_id__: "DisableSuggestions",
    __is_disabled_plugin__: false,
    async requestDidStart() {
      return {
        async validationDidStart() {
          return async (validationErrors) => {
            validationErrors?.forEach((error) => {
              error.message = error.message.replace(/ ?Did you mean(.+?)\?$/, "");
            });
          };
        }
      };
    }
  });
}
exports.ApolloServerPluginDisableSuggestions = ApolloServerPluginDisableSuggestions;
