"use strict";
const index = require("../index.js");
var minimalExports = index.requireMinimal();
const $protobuf = /* @__PURE__ */ index.getDefaultExportFromCjs(minimalExports);
const $Reader = $protobuf.Reader, $Writer = $protobuf.Writer, $util = $protobuf.util;
const $root = $protobuf.roots["default"] || ($protobuf.roots["default"] = {});
const Trace = $root.Trace = (() => {
  function Trace2(properties) {
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  Trace2.prototype.startTime = null;
  Trace2.prototype.endTime = null;
  Trace2.prototype.durationNs = 0;
  Trace2.prototype.root = null;
  Trace2.prototype.isIncomplete = false;
  Trace2.prototype.signature = "";
  Trace2.prototype.unexecutedOperationBody = "";
  Trace2.prototype.unexecutedOperationName = "";
  Trace2.prototype.details = null;
  Trace2.prototype.clientName = "";
  Trace2.prototype.clientVersion = "";
  Trace2.prototype.http = null;
  Trace2.prototype.cachePolicy = null;
  Trace2.prototype.queryPlan = null;
  Trace2.prototype.fullQueryCacheHit = false;
  Trace2.prototype.persistedQueryHit = false;
  Trace2.prototype.persistedQueryRegister = false;
  Trace2.prototype.registeredOperation = false;
  Trace2.prototype.forbiddenOperation = false;
  Trace2.prototype.fieldExecutionWeight = 0;
  Trace2.create = function create(properties) {
    return new Trace2(properties);
  };
  Trace2.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.endTime != null && Object.hasOwnProperty.call(message, "endTime"))
      $root.google.protobuf.Timestamp.encode(message.endTime, writer.uint32(
        /* id 3, wireType 2 =*/
        26
      ).fork()).ldelim();
    if (message.startTime != null && Object.hasOwnProperty.call(message, "startTime"))
      $root.google.protobuf.Timestamp.encode(message.startTime, writer.uint32(
        /* id 4, wireType 2 =*/
        34
      ).fork()).ldelim();
    if (message.details != null && Object.hasOwnProperty.call(message, "details"))
      $root.Trace.Details.encode(message.details, writer.uint32(
        /* id 6, wireType 2 =*/
        50
      ).fork()).ldelim();
    if (message.clientName != null && Object.hasOwnProperty.call(message, "clientName"))
      writer.uint32(
        /* id 7, wireType 2 =*/
        58
      ).string(message.clientName);
    if (message.clientVersion != null && Object.hasOwnProperty.call(message, "clientVersion"))
      writer.uint32(
        /* id 8, wireType 2 =*/
        66
      ).string(message.clientVersion);
    if (message.http != null && Object.hasOwnProperty.call(message, "http"))
      $root.Trace.HTTP.encode(message.http, writer.uint32(
        /* id 10, wireType 2 =*/
        82
      ).fork()).ldelim();
    if (message.durationNs != null && Object.hasOwnProperty.call(message, "durationNs"))
      writer.uint32(
        /* id 11, wireType 0 =*/
        88
      ).uint64(message.durationNs);
    if (message.root != null && Object.hasOwnProperty.call(message, "root"))
      $root.Trace.Node.encode(message.root, writer.uint32(
        /* id 14, wireType 2 =*/
        114
      ).fork()).ldelim();
    if (message.cachePolicy != null && Object.hasOwnProperty.call(message, "cachePolicy"))
      $root.Trace.CachePolicy.encode(message.cachePolicy, writer.uint32(
        /* id 18, wireType 2 =*/
        146
      ).fork()).ldelim();
    if (message.signature != null && Object.hasOwnProperty.call(message, "signature"))
      writer.uint32(
        /* id 19, wireType 2 =*/
        154
      ).string(message.signature);
    if (message.fullQueryCacheHit != null && Object.hasOwnProperty.call(message, "fullQueryCacheHit"))
      writer.uint32(
        /* id 20, wireType 0 =*/
        160
      ).bool(message.fullQueryCacheHit);
    if (message.persistedQueryHit != null && Object.hasOwnProperty.call(message, "persistedQueryHit"))
      writer.uint32(
        /* id 21, wireType 0 =*/
        168
      ).bool(message.persistedQueryHit);
    if (message.persistedQueryRegister != null && Object.hasOwnProperty.call(message, "persistedQueryRegister"))
      writer.uint32(
        /* id 22, wireType 0 =*/
        176
      ).bool(message.persistedQueryRegister);
    if (message.registeredOperation != null && Object.hasOwnProperty.call(message, "registeredOperation"))
      writer.uint32(
        /* id 24, wireType 0 =*/
        192
      ).bool(message.registeredOperation);
    if (message.forbiddenOperation != null && Object.hasOwnProperty.call(message, "forbiddenOperation"))
      writer.uint32(
        /* id 25, wireType 0 =*/
        200
      ).bool(message.forbiddenOperation);
    if (message.queryPlan != null && Object.hasOwnProperty.call(message, "queryPlan"))
      $root.Trace.QueryPlanNode.encode(message.queryPlan, writer.uint32(
        /* id 26, wireType 2 =*/
        210
      ).fork()).ldelim();
    if (message.unexecutedOperationBody != null && Object.hasOwnProperty.call(message, "unexecutedOperationBody"))
      writer.uint32(
        /* id 27, wireType 2 =*/
        218
      ).string(message.unexecutedOperationBody);
    if (message.unexecutedOperationName != null && Object.hasOwnProperty.call(message, "unexecutedOperationName"))
      writer.uint32(
        /* id 28, wireType 2 =*/
        226
      ).string(message.unexecutedOperationName);
    if (message.fieldExecutionWeight != null && Object.hasOwnProperty.call(message, "fieldExecutionWeight"))
      writer.uint32(
        /* id 31, wireType 1 =*/
        249
      ).double(message.fieldExecutionWeight);
    if (message.isIncomplete != null && Object.hasOwnProperty.call(message, "isIncomplete"))
      writer.uint32(
        /* id 33, wireType 0 =*/
        264
      ).bool(message.isIncomplete);
    return writer;
  };
  Trace2.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  Trace2.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace();
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 4:
          message.startTime = $root.google.protobuf.Timestamp.decode(reader, reader.uint32());
          break;
        case 3:
          message.endTime = $root.google.protobuf.Timestamp.decode(reader, reader.uint32());
          break;
        case 11:
          message.durationNs = reader.uint64();
          break;
        case 14:
          message.root = $root.Trace.Node.decode(reader, reader.uint32());
          break;
        case 33:
          message.isIncomplete = reader.bool();
          break;
        case 19:
          message.signature = reader.string();
          break;
        case 27:
          message.unexecutedOperationBody = reader.string();
          break;
        case 28:
          message.unexecutedOperationName = reader.string();
          break;
        case 6:
          message.details = $root.Trace.Details.decode(reader, reader.uint32());
          break;
        case 7:
          message.clientName = reader.string();
          break;
        case 8:
          message.clientVersion = reader.string();
          break;
        case 10:
          message.http = $root.Trace.HTTP.decode(reader, reader.uint32());
          break;
        case 18:
          message.cachePolicy = $root.Trace.CachePolicy.decode(reader, reader.uint32());
          break;
        case 26:
          message.queryPlan = $root.Trace.QueryPlanNode.decode(reader, reader.uint32());
          break;
        case 20:
          message.fullQueryCacheHit = reader.bool();
          break;
        case 21:
          message.persistedQueryHit = reader.bool();
          break;
        case 22:
          message.persistedQueryRegister = reader.bool();
          break;
        case 24:
          message.registeredOperation = reader.bool();
          break;
        case 25:
          message.forbiddenOperation = reader.bool();
          break;
        case 31:
          message.fieldExecutionWeight = reader.double();
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  Trace2.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  Trace2.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.startTime != null && message.hasOwnProperty("startTime")) {
      let error = $root.google.protobuf.Timestamp.verify(message.startTime);
      if (error)
        return "startTime." + error;
    }
    if (message.endTime != null && message.hasOwnProperty("endTime")) {
      let error = $root.google.protobuf.Timestamp.verify(message.endTime);
      if (error)
        return "endTime." + error;
    }
    if (message.durationNs != null && message.hasOwnProperty("durationNs")) {
      if (!$util.isInteger(message.durationNs) && !(message.durationNs && $util.isInteger(message.durationNs.low) && $util.isInteger(message.durationNs.high)))
        return "durationNs: integer|Long expected";
    }
    if (message.root != null && message.hasOwnProperty("root")) {
      let error = $root.Trace.Node.verify(message.root);
      if (error)
        return "root." + error;
    }
    if (message.isIncomplete != null && message.hasOwnProperty("isIncomplete")) {
      if (typeof message.isIncomplete !== "boolean")
        return "isIncomplete: boolean expected";
    }
    if (message.signature != null && message.hasOwnProperty("signature")) {
      if (!$util.isString(message.signature))
        return "signature: string expected";
    }
    if (message.unexecutedOperationBody != null && message.hasOwnProperty("unexecutedOperationBody")) {
      if (!$util.isString(message.unexecutedOperationBody))
        return "unexecutedOperationBody: string expected";
    }
    if (message.unexecutedOperationName != null && message.hasOwnProperty("unexecutedOperationName")) {
      if (!$util.isString(message.unexecutedOperationName))
        return "unexecutedOperationName: string expected";
    }
    if (message.details != null && message.hasOwnProperty("details")) {
      let error = $root.Trace.Details.verify(message.details);
      if (error)
        return "details." + error;
    }
    if (message.clientName != null && message.hasOwnProperty("clientName")) {
      if (!$util.isString(message.clientName))
        return "clientName: string expected";
    }
    if (message.clientVersion != null && message.hasOwnProperty("clientVersion")) {
      if (!$util.isString(message.clientVersion))
        return "clientVersion: string expected";
    }
    if (message.http != null && message.hasOwnProperty("http")) {
      let error = $root.Trace.HTTP.verify(message.http);
      if (error)
        return "http." + error;
    }
    if (message.cachePolicy != null && message.hasOwnProperty("cachePolicy")) {
      let error = $root.Trace.CachePolicy.verify(message.cachePolicy);
      if (error)
        return "cachePolicy." + error;
    }
    if (message.queryPlan != null && message.hasOwnProperty("queryPlan")) {
      let error = $root.Trace.QueryPlanNode.verify(message.queryPlan);
      if (error)
        return "queryPlan." + error;
    }
    if (message.fullQueryCacheHit != null && message.hasOwnProperty("fullQueryCacheHit")) {
      if (typeof message.fullQueryCacheHit !== "boolean")
        return "fullQueryCacheHit: boolean expected";
    }
    if (message.persistedQueryHit != null && message.hasOwnProperty("persistedQueryHit")) {
      if (typeof message.persistedQueryHit !== "boolean")
        return "persistedQueryHit: boolean expected";
    }
    if (message.persistedQueryRegister != null && message.hasOwnProperty("persistedQueryRegister")) {
      if (typeof message.persistedQueryRegister !== "boolean")
        return "persistedQueryRegister: boolean expected";
    }
    if (message.registeredOperation != null && message.hasOwnProperty("registeredOperation")) {
      if (typeof message.registeredOperation !== "boolean")
        return "registeredOperation: boolean expected";
    }
    if (message.forbiddenOperation != null && message.hasOwnProperty("forbiddenOperation")) {
      if (typeof message.forbiddenOperation !== "boolean")
        return "forbiddenOperation: boolean expected";
    }
    if (message.fieldExecutionWeight != null && message.hasOwnProperty("fieldExecutionWeight")) {
      if (typeof message.fieldExecutionWeight !== "number")
        return "fieldExecutionWeight: number expected";
    }
    return null;
  };
  Trace2.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.defaults) {
      object.endTime = null;
      object.startTime = null;
      object.details = null;
      object.clientName = "";
      object.clientVersion = "";
      object.http = null;
      object.durationNs = 0;
      object.root = null;
      object.cachePolicy = null;
      object.signature = "";
      object.fullQueryCacheHit = false;
      object.persistedQueryHit = false;
      object.persistedQueryRegister = false;
      object.registeredOperation = false;
      object.forbiddenOperation = false;
      object.queryPlan = null;
      object.unexecutedOperationBody = "";
      object.unexecutedOperationName = "";
      object.fieldExecutionWeight = 0;
      object.isIncomplete = false;
    }
    if (message.endTime != null && message.hasOwnProperty("endTime"))
      object.endTime = $root.google.protobuf.Timestamp.toObject(message.endTime, options);
    if (message.startTime != null && message.hasOwnProperty("startTime"))
      object.startTime = $root.google.protobuf.Timestamp.toObject(message.startTime, options);
    if (message.details != null && message.hasOwnProperty("details"))
      object.details = $root.Trace.Details.toObject(message.details, options);
    if (message.clientName != null && message.hasOwnProperty("clientName"))
      object.clientName = message.clientName;
    if (message.clientVersion != null && message.hasOwnProperty("clientVersion"))
      object.clientVersion = message.clientVersion;
    if (message.http != null && message.hasOwnProperty("http"))
      object.http = $root.Trace.HTTP.toObject(message.http, options);
    if (message.durationNs != null && message.hasOwnProperty("durationNs"))
      if (typeof message.durationNs === "number")
        object.durationNs = options.longs === String ? String(message.durationNs) : message.durationNs;
      else
        object.durationNs = options.longs === String ? $util.Long.prototype.toString.call(message.durationNs) : options.longs === Number ? new $util.LongBits(message.durationNs.low >>> 0, message.durationNs.high >>> 0).toNumber(true) : message.durationNs;
    if (message.root != null && message.hasOwnProperty("root"))
      object.root = $root.Trace.Node.toObject(message.root, options);
    if (message.cachePolicy != null && message.hasOwnProperty("cachePolicy"))
      object.cachePolicy = $root.Trace.CachePolicy.toObject(message.cachePolicy, options);
    if (message.signature != null && message.hasOwnProperty("signature"))
      object.signature = message.signature;
    if (message.fullQueryCacheHit != null && message.hasOwnProperty("fullQueryCacheHit"))
      object.fullQueryCacheHit = message.fullQueryCacheHit;
    if (message.persistedQueryHit != null && message.hasOwnProperty("persistedQueryHit"))
      object.persistedQueryHit = message.persistedQueryHit;
    if (message.persistedQueryRegister != null && message.hasOwnProperty("persistedQueryRegister"))
      object.persistedQueryRegister = message.persistedQueryRegister;
    if (message.registeredOperation != null && message.hasOwnProperty("registeredOperation"))
      object.registeredOperation = message.registeredOperation;
    if (message.forbiddenOperation != null && message.hasOwnProperty("forbiddenOperation"))
      object.forbiddenOperation = message.forbiddenOperation;
    if (message.queryPlan != null && message.hasOwnProperty("queryPlan"))
      object.queryPlan = $root.Trace.QueryPlanNode.toObject(message.queryPlan, options);
    if (message.unexecutedOperationBody != null && message.hasOwnProperty("unexecutedOperationBody"))
      object.unexecutedOperationBody = message.unexecutedOperationBody;
    if (message.unexecutedOperationName != null && message.hasOwnProperty("unexecutedOperationName"))
      object.unexecutedOperationName = message.unexecutedOperationName;
    if (message.fieldExecutionWeight != null && message.hasOwnProperty("fieldExecutionWeight"))
      object.fieldExecutionWeight = options.json && !isFinite(message.fieldExecutionWeight) ? String(message.fieldExecutionWeight) : message.fieldExecutionWeight;
    if (message.isIncomplete != null && message.hasOwnProperty("isIncomplete"))
      object.isIncomplete = message.isIncomplete;
    return object;
  };
  Trace2.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  Trace2.CachePolicy = (function() {
    function CachePolicy(properties) {
      if (properties) {
        for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
          if (properties[keys[i]] != null)
            this[keys[i]] = properties[keys[i]];
      }
    }
    CachePolicy.prototype.scope = 0;
    CachePolicy.prototype.maxAgeNs = 0;
    CachePolicy.create = function create(properties) {
      return new CachePolicy(properties);
    };
    CachePolicy.encode = function encode(message, writer) {
      if (!writer)
        writer = $Writer.create();
      if (message.scope != null && Object.hasOwnProperty.call(message, "scope"))
        writer.uint32(
          /* id 1, wireType 0 =*/
          8
        ).int32(message.scope);
      if (message.maxAgeNs != null && Object.hasOwnProperty.call(message, "maxAgeNs"))
        writer.uint32(
          /* id 2, wireType 0 =*/
          16
        ).int64(message.maxAgeNs);
      return writer;
    };
    CachePolicy.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    CachePolicy.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader))
        reader = $Reader.create(reader);
      let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.CachePolicy();
      while (reader.pos < end) {
        let tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.scope = reader.int32();
            break;
          case 2:
            message.maxAgeNs = reader.int64();
            break;
          default:
            reader.skipType(tag & 7);
            break;
        }
      }
      return message;
    };
    CachePolicy.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader))
        reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    CachePolicy.verify = function verify(message) {
      if (typeof message !== "object" || message === null)
        return "object expected";
      if (message.scope != null && message.hasOwnProperty("scope"))
        switch (message.scope) {
          default:
            return "scope: enum value expected";
          case 0:
          case 1:
          case 2:
            break;
        }
      if (message.maxAgeNs != null && message.hasOwnProperty("maxAgeNs")) {
        if (!$util.isInteger(message.maxAgeNs) && !(message.maxAgeNs && $util.isInteger(message.maxAgeNs.low) && $util.isInteger(message.maxAgeNs.high)))
          return "maxAgeNs: integer|Long expected";
      }
      return null;
    };
    CachePolicy.toObject = function toObject(message, options) {
      if (!options)
        options = {};
      let object = {};
      if (options.defaults) {
        object.scope = options.enums === String ? "UNKNOWN" : 0;
        object.maxAgeNs = 0;
      }
      if (message.scope != null && message.hasOwnProperty("scope"))
        object.scope = options.enums === String ? $root.Trace.CachePolicy.Scope[message.scope] : message.scope;
      if (message.maxAgeNs != null && message.hasOwnProperty("maxAgeNs"))
        if (typeof message.maxAgeNs === "number")
          object.maxAgeNs = options.longs === String ? String(message.maxAgeNs) : message.maxAgeNs;
        else
          object.maxAgeNs = options.longs === String ? $util.Long.prototype.toString.call(message.maxAgeNs) : options.longs === Number ? new $util.LongBits(message.maxAgeNs.low >>> 0, message.maxAgeNs.high >>> 0).toNumber() : message.maxAgeNs;
      return object;
    };
    CachePolicy.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };
    CachePolicy.Scope = (function() {
      const valuesById = {}, values = Object.create(valuesById);
      values[valuesById[0] = "UNKNOWN"] = 0;
      values[valuesById[1] = "PUBLIC"] = 1;
      values[valuesById[2] = "PRIVATE"] = 2;
      return values;
    })();
    return CachePolicy;
  })();
  Trace2.Details = (function() {
    function Details(properties) {
      this.variablesJson = {};
      if (properties) {
        for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
          if (properties[keys[i]] != null)
            this[keys[i]] = properties[keys[i]];
      }
    }
    Details.prototype.variablesJson = $util.emptyObject;
    Details.prototype.operationName = "";
    Details.create = function create(properties) {
      return new Details(properties);
    };
    Details.encode = function encode(message, writer) {
      if (!writer)
        writer = $Writer.create();
      if (message.operationName != null && Object.hasOwnProperty.call(message, "operationName"))
        writer.uint32(
          /* id 3, wireType 2 =*/
          26
        ).string(message.operationName);
      if (message.variablesJson != null && Object.hasOwnProperty.call(message, "variablesJson"))
        for (let keys = Object.keys(message.variablesJson), i = 0; i < keys.length; ++i)
          writer.uint32(
            /* id 4, wireType 2 =*/
            34
          ).fork().uint32(
            /* id 1, wireType 2 =*/
            10
          ).string(keys[i]).uint32(
            /* id 2, wireType 2 =*/
            18
          ).string(message.variablesJson[keys[i]]).ldelim();
      return writer;
    };
    Details.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    Details.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader))
        reader = $Reader.create(reader);
      let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.Details(), key;
      while (reader.pos < end) {
        let tag = reader.uint32();
        switch (tag >>> 3) {
          case 4:
            reader.skip().pos++;
            if (message.variablesJson === $util.emptyObject)
              message.variablesJson = {};
            key = reader.string();
            reader.pos++;
            message.variablesJson[key] = reader.string();
            break;
          case 3:
            message.operationName = reader.string();
            break;
          default:
            reader.skipType(tag & 7);
            break;
        }
      }
      return message;
    };
    Details.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader))
        reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    Details.verify = function verify(message) {
      if (typeof message !== "object" || message === null)
        return "object expected";
      if (message.variablesJson != null && message.hasOwnProperty("variablesJson")) {
        if (!$util.isObject(message.variablesJson))
          return "variablesJson: object expected";
        let key = Object.keys(message.variablesJson);
        for (let i = 0; i < key.length; ++i)
          if (!$util.isString(message.variablesJson[key[i]]))
            return "variablesJson: string{k:string} expected";
      }
      if (message.operationName != null && message.hasOwnProperty("operationName")) {
        if (!$util.isString(message.operationName))
          return "operationName: string expected";
      }
      return null;
    };
    Details.toObject = function toObject(message, options) {
      if (!options)
        options = {};
      let object = {};
      if (options.objects || options.defaults)
        object.variablesJson = {};
      if (options.defaults)
        object.operationName = "";
      if (message.operationName != null && message.hasOwnProperty("operationName"))
        object.operationName = message.operationName;
      let keys2;
      if (message.variablesJson && (keys2 = Object.keys(message.variablesJson)).length) {
        object.variablesJson = {};
        for (let j = 0; j < keys2.length; ++j)
          object.variablesJson[keys2[j]] = message.variablesJson[keys2[j]];
      }
      return object;
    };
    Details.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };
    return Details;
  })();
  Trace2.Error = (function() {
    function Error2(properties) {
      this.location = [];
      if (properties) {
        for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
          if (properties[keys[i]] != null)
            this[keys[i]] = properties[keys[i]];
      }
    }
    Error2.prototype.message = "";
    Error2.prototype.location = $util.emptyArray;
    Error2.prototype.timeNs = 0;
    Error2.prototype.json = "";
    Error2.create = function create(properties) {
      return new Error2(properties);
    };
    Error2.encode = function encode(message, writer) {
      if (!writer)
        writer = $Writer.create();
      if (message.message != null && Object.hasOwnProperty.call(message, "message"))
        writer.uint32(
          /* id 1, wireType 2 =*/
          10
        ).string(message.message);
      if (message.location != null && message.location.length)
        for (let i = 0; i < message.location.length; ++i)
          $root.Trace.Location.encode(message.location[i], writer.uint32(
            /* id 2, wireType 2 =*/
            18
          ).fork()).ldelim();
      if (message.timeNs != null && Object.hasOwnProperty.call(message, "timeNs"))
        writer.uint32(
          /* id 3, wireType 0 =*/
          24
        ).uint64(message.timeNs);
      if (message.json != null && Object.hasOwnProperty.call(message, "json"))
        writer.uint32(
          /* id 4, wireType 2 =*/
          34
        ).string(message.json);
      return writer;
    };
    Error2.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    Error2.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader))
        reader = $Reader.create(reader);
      let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.Error();
      while (reader.pos < end) {
        let tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.message = reader.string();
            break;
          case 2:
            if (!(message.location && message.location.length))
              message.location = [];
            message.location.push($root.Trace.Location.decode(reader, reader.uint32()));
            break;
          case 3:
            message.timeNs = reader.uint64();
            break;
          case 4:
            message.json = reader.string();
            break;
          default:
            reader.skipType(tag & 7);
            break;
        }
      }
      return message;
    };
    Error2.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader))
        reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    Error2.verify = function verify(message) {
      if (typeof message !== "object" || message === null)
        return "object expected";
      if (message.message != null && message.hasOwnProperty("message")) {
        if (!$util.isString(message.message))
          return "message: string expected";
      }
      if (message.location != null && message.hasOwnProperty("location")) {
        if (!Array.isArray(message.location))
          return "location: array expected";
        for (let i = 0; i < message.location.length; ++i) {
          let error = $root.Trace.Location.verify(message.location[i]);
          if (error)
            return "location." + error;
        }
      }
      if (message.timeNs != null && message.hasOwnProperty("timeNs")) {
        if (!$util.isInteger(message.timeNs) && !(message.timeNs && $util.isInteger(message.timeNs.low) && $util.isInteger(message.timeNs.high)))
          return "timeNs: integer|Long expected";
      }
      if (message.json != null && message.hasOwnProperty("json")) {
        if (!$util.isString(message.json))
          return "json: string expected";
      }
      return null;
    };
    Error2.toObject = function toObject(message, options) {
      if (!options)
        options = {};
      let object = {};
      if (options.arrays || options.defaults)
        object.location = [];
      if (options.defaults) {
        object.message = "";
        object.timeNs = 0;
        object.json = "";
      }
      if (message.message != null && message.hasOwnProperty("message"))
        object.message = message.message;
      if (message.location && message.location.length) {
        object.location = [];
        for (let j = 0; j < message.location.length; ++j)
          object.location[j] = $root.Trace.Location.toObject(message.location[j], options);
      }
      if (message.timeNs != null && message.hasOwnProperty("timeNs"))
        if (typeof message.timeNs === "number")
          object.timeNs = options.longs === String ? String(message.timeNs) : message.timeNs;
        else
          object.timeNs = options.longs === String ? $util.Long.prototype.toString.call(message.timeNs) : options.longs === Number ? new $util.LongBits(message.timeNs.low >>> 0, message.timeNs.high >>> 0).toNumber(true) : message.timeNs;
      if (message.json != null && message.hasOwnProperty("json"))
        object.json = message.json;
      return object;
    };
    Error2.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };
    return Error2;
  })();
  Trace2.HTTP = (function() {
    function HTTP(properties) {
      this.requestHeaders = {};
      this.responseHeaders = {};
      if (properties) {
        for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
          if (properties[keys[i]] != null)
            this[keys[i]] = properties[keys[i]];
      }
    }
    HTTP.prototype.method = 0;
    HTTP.prototype.requestHeaders = $util.emptyObject;
    HTTP.prototype.responseHeaders = $util.emptyObject;
    HTTP.prototype.statusCode = 0;
    HTTP.create = function create(properties) {
      return new HTTP(properties);
    };
    HTTP.encode = function encode(message, writer) {
      if (!writer)
        writer = $Writer.create();
      if (message.method != null && Object.hasOwnProperty.call(message, "method"))
        writer.uint32(
          /* id 1, wireType 0 =*/
          8
        ).int32(message.method);
      if (message.requestHeaders != null && Object.hasOwnProperty.call(message, "requestHeaders"))
        for (let keys = Object.keys(message.requestHeaders), i = 0; i < keys.length; ++i) {
          writer.uint32(
            /* id 4, wireType 2 =*/
            34
          ).fork().uint32(
            /* id 1, wireType 2 =*/
            10
          ).string(keys[i]);
          $root.Trace.HTTP.Values.encode(message.requestHeaders[keys[i]], writer.uint32(
            /* id 2, wireType 2 =*/
            18
          ).fork()).ldelim().ldelim();
        }
      if (message.responseHeaders != null && Object.hasOwnProperty.call(message, "responseHeaders"))
        for (let keys = Object.keys(message.responseHeaders), i = 0; i < keys.length; ++i) {
          writer.uint32(
            /* id 5, wireType 2 =*/
            42
          ).fork().uint32(
            /* id 1, wireType 2 =*/
            10
          ).string(keys[i]);
          $root.Trace.HTTP.Values.encode(message.responseHeaders[keys[i]], writer.uint32(
            /* id 2, wireType 2 =*/
            18
          ).fork()).ldelim().ldelim();
        }
      if (message.statusCode != null && Object.hasOwnProperty.call(message, "statusCode"))
        writer.uint32(
          /* id 6, wireType 0 =*/
          48
        ).uint32(message.statusCode);
      return writer;
    };
    HTTP.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    HTTP.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader))
        reader = $Reader.create(reader);
      let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.HTTP(), key;
      while (reader.pos < end) {
        let tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.method = reader.int32();
            break;
          case 4:
            reader.skip().pos++;
            if (message.requestHeaders === $util.emptyObject)
              message.requestHeaders = {};
            key = reader.string();
            reader.pos++;
            message.requestHeaders[key] = $root.Trace.HTTP.Values.decode(reader, reader.uint32());
            break;
          case 5:
            reader.skip().pos++;
            if (message.responseHeaders === $util.emptyObject)
              message.responseHeaders = {};
            key = reader.string();
            reader.pos++;
            message.responseHeaders[key] = $root.Trace.HTTP.Values.decode(reader, reader.uint32());
            break;
          case 6:
            message.statusCode = reader.uint32();
            break;
          default:
            reader.skipType(tag & 7);
            break;
        }
      }
      return message;
    };
    HTTP.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader))
        reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    HTTP.verify = function verify(message) {
      if (typeof message !== "object" || message === null)
        return "object expected";
      if (message.method != null && message.hasOwnProperty("method"))
        switch (message.method) {
          default:
            return "method: enum value expected";
          case 0:
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
          case 6:
          case 7:
          case 8:
          case 9:
            break;
        }
      if (message.requestHeaders != null && message.hasOwnProperty("requestHeaders")) {
        if (!$util.isObject(message.requestHeaders))
          return "requestHeaders: object expected";
        let key = Object.keys(message.requestHeaders);
        for (let i = 0; i < key.length; ++i) {
          let error = $root.Trace.HTTP.Values.verify(message.requestHeaders[key[i]]);
          if (error)
            return "requestHeaders." + error;
        }
      }
      if (message.responseHeaders != null && message.hasOwnProperty("responseHeaders")) {
        if (!$util.isObject(message.responseHeaders))
          return "responseHeaders: object expected";
        let key = Object.keys(message.responseHeaders);
        for (let i = 0; i < key.length; ++i) {
          let error = $root.Trace.HTTP.Values.verify(message.responseHeaders[key[i]]);
          if (error)
            return "responseHeaders." + error;
        }
      }
      if (message.statusCode != null && message.hasOwnProperty("statusCode")) {
        if (!$util.isInteger(message.statusCode))
          return "statusCode: integer expected";
      }
      return null;
    };
    HTTP.toObject = function toObject(message, options) {
      if (!options)
        options = {};
      let object = {};
      if (options.objects || options.defaults) {
        object.requestHeaders = {};
        object.responseHeaders = {};
      }
      if (options.defaults) {
        object.method = options.enums === String ? "UNKNOWN" : 0;
        object.statusCode = 0;
      }
      if (message.method != null && message.hasOwnProperty("method"))
        object.method = options.enums === String ? $root.Trace.HTTP.Method[message.method] : message.method;
      let keys2;
      if (message.requestHeaders && (keys2 = Object.keys(message.requestHeaders)).length) {
        object.requestHeaders = {};
        for (let j = 0; j < keys2.length; ++j)
          object.requestHeaders[keys2[j]] = $root.Trace.HTTP.Values.toObject(message.requestHeaders[keys2[j]], options);
      }
      if (message.responseHeaders && (keys2 = Object.keys(message.responseHeaders)).length) {
        object.responseHeaders = {};
        for (let j = 0; j < keys2.length; ++j)
          object.responseHeaders[keys2[j]] = $root.Trace.HTTP.Values.toObject(message.responseHeaders[keys2[j]], options);
      }
      if (message.statusCode != null && message.hasOwnProperty("statusCode"))
        object.statusCode = message.statusCode;
      return object;
    };
    HTTP.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };
    HTTP.Values = (function() {
      function Values(properties) {
        this.value = [];
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      Values.prototype.value = $util.emptyArray;
      Values.create = function create(properties) {
        return new Values(properties);
      };
      Values.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.value != null && message.value.length)
          for (let i = 0; i < message.value.length; ++i)
            writer.uint32(
              /* id 1, wireType 2 =*/
              10
            ).string(message.value[i]);
        return writer;
      };
      Values.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      Values.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.HTTP.Values();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              if (!(message.value && message.value.length))
                message.value = [];
              message.value.push(reader.string());
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      Values.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      Values.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        if (message.value != null && message.hasOwnProperty("value")) {
          if (!Array.isArray(message.value))
            return "value: array expected";
          for (let i = 0; i < message.value.length; ++i)
            if (!$util.isString(message.value[i]))
              return "value: string[] expected";
        }
        return null;
      };
      Values.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (options.arrays || options.defaults)
          object.value = [];
        if (message.value && message.value.length) {
          object.value = [];
          for (let j = 0; j < message.value.length; ++j)
            object.value[j] = message.value[j];
        }
        return object;
      };
      Values.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return Values;
    })();
    HTTP.Method = (function() {
      const valuesById = {}, values = Object.create(valuesById);
      values[valuesById[0] = "UNKNOWN"] = 0;
      values[valuesById[1] = "OPTIONS"] = 1;
      values[valuesById[2] = "GET"] = 2;
      values[valuesById[3] = "HEAD"] = 3;
      values[valuesById[4] = "POST"] = 4;
      values[valuesById[5] = "PUT"] = 5;
      values[valuesById[6] = "DELETE"] = 6;
      values[valuesById[7] = "TRACE"] = 7;
      values[valuesById[8] = "CONNECT"] = 8;
      values[valuesById[9] = "PATCH"] = 9;
      return values;
    })();
    return HTTP;
  })();
  Trace2.Location = (function() {
    function Location(properties) {
      if (properties) {
        for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
          if (properties[keys[i]] != null)
            this[keys[i]] = properties[keys[i]];
      }
    }
    Location.prototype.line = 0;
    Location.prototype.column = 0;
    Location.create = function create(properties) {
      return new Location(properties);
    };
    Location.encode = function encode(message, writer) {
      if (!writer)
        writer = $Writer.create();
      if (message.line != null && Object.hasOwnProperty.call(message, "line"))
        writer.uint32(
          /* id 1, wireType 0 =*/
          8
        ).uint32(message.line);
      if (message.column != null && Object.hasOwnProperty.call(message, "column"))
        writer.uint32(
          /* id 2, wireType 0 =*/
          16
        ).uint32(message.column);
      return writer;
    };
    Location.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    Location.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader))
        reader = $Reader.create(reader);
      let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.Location();
      while (reader.pos < end) {
        let tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.line = reader.uint32();
            break;
          case 2:
            message.column = reader.uint32();
            break;
          default:
            reader.skipType(tag & 7);
            break;
        }
      }
      return message;
    };
    Location.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader))
        reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    Location.verify = function verify(message) {
      if (typeof message !== "object" || message === null)
        return "object expected";
      if (message.line != null && message.hasOwnProperty("line")) {
        if (!$util.isInteger(message.line))
          return "line: integer expected";
      }
      if (message.column != null && message.hasOwnProperty("column")) {
        if (!$util.isInteger(message.column))
          return "column: integer expected";
      }
      return null;
    };
    Location.toObject = function toObject(message, options) {
      if (!options)
        options = {};
      let object = {};
      if (options.defaults) {
        object.line = 0;
        object.column = 0;
      }
      if (message.line != null && message.hasOwnProperty("line"))
        object.line = message.line;
      if (message.column != null && message.hasOwnProperty("column"))
        object.column = message.column;
      return object;
    };
    Location.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };
    return Location;
  })();
  Trace2.Node = (function() {
    function Node(properties) {
      this.error = [];
      this.child = [];
      if (properties) {
        for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
          if (properties[keys[i]] != null)
            this[keys[i]] = properties[keys[i]];
      }
    }
    Node.prototype.responseName = "";
    Node.prototype.index = 0;
    Node.prototype.originalFieldName = "";
    Node.prototype.type = "";
    Node.prototype.parentType = "";
    Node.prototype.cachePolicy = null;
    Node.prototype.startTime = 0;
    Node.prototype.endTime = 0;
    Node.prototype.error = $util.emptyArray;
    Node.prototype.child = $util.emptyArray;
    let $oneOfFields;
    Object.defineProperty(Node.prototype, "id", {
      get: $util.oneOfGetter($oneOfFields = ["responseName", "index"]),
      set: $util.oneOfSetter($oneOfFields)
    });
    Node.create = function create(properties) {
      return new Node(properties);
    };
    Node.encode = function encode(message, writer) {
      if (!writer)
        writer = $Writer.create();
      if (message.responseName != null && Object.hasOwnProperty.call(message, "responseName"))
        writer.uint32(
          /* id 1, wireType 2 =*/
          10
        ).string(message.responseName);
      if (message.index != null && Object.hasOwnProperty.call(message, "index"))
        writer.uint32(
          /* id 2, wireType 0 =*/
          16
        ).uint32(message.index);
      if (message.type != null && Object.hasOwnProperty.call(message, "type"))
        writer.uint32(
          /* id 3, wireType 2 =*/
          26
        ).string(message.type);
      if (message.cachePolicy != null && Object.hasOwnProperty.call(message, "cachePolicy"))
        $root.Trace.CachePolicy.encode(message.cachePolicy, writer.uint32(
          /* id 5, wireType 2 =*/
          42
        ).fork()).ldelim();
      if (message.startTime != null && Object.hasOwnProperty.call(message, "startTime"))
        writer.uint32(
          /* id 8, wireType 0 =*/
          64
        ).uint64(message.startTime);
      if (message.endTime != null && Object.hasOwnProperty.call(message, "endTime"))
        writer.uint32(
          /* id 9, wireType 0 =*/
          72
        ).uint64(message.endTime);
      if (message.error != null && message.error.length)
        for (let i = 0; i < message.error.length; ++i)
          $root.Trace.Error.encode(message.error[i], writer.uint32(
            /* id 11, wireType 2 =*/
            90
          ).fork()).ldelim();
      if (message.child != null && message.child.length)
        for (let i = 0; i < message.child.length; ++i)
          $root.Trace.Node.encode(message.child[i], writer.uint32(
            /* id 12, wireType 2 =*/
            98
          ).fork()).ldelim();
      if (message.parentType != null && Object.hasOwnProperty.call(message, "parentType"))
        writer.uint32(
          /* id 13, wireType 2 =*/
          106
        ).string(message.parentType);
      if (message.originalFieldName != null && Object.hasOwnProperty.call(message, "originalFieldName"))
        writer.uint32(
          /* id 14, wireType 2 =*/
          114
        ).string(message.originalFieldName);
      return writer;
    };
    Node.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    Node.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader))
        reader = $Reader.create(reader);
      let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.Node();
      while (reader.pos < end) {
        let tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.responseName = reader.string();
            break;
          case 2:
            message.index = reader.uint32();
            break;
          case 14:
            message.originalFieldName = reader.string();
            break;
          case 3:
            message.type = reader.string();
            break;
          case 13:
            message.parentType = reader.string();
            break;
          case 5:
            message.cachePolicy = $root.Trace.CachePolicy.decode(reader, reader.uint32());
            break;
          case 8:
            message.startTime = reader.uint64();
            break;
          case 9:
            message.endTime = reader.uint64();
            break;
          case 11:
            if (!(message.error && message.error.length))
              message.error = [];
            message.error.push($root.Trace.Error.decode(reader, reader.uint32()));
            break;
          case 12:
            if (!(message.child && message.child.length))
              message.child = [];
            message.child.push($root.Trace.Node.decode(reader, reader.uint32()));
            break;
          default:
            reader.skipType(tag & 7);
            break;
        }
      }
      return message;
    };
    Node.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader))
        reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    Node.verify = function verify(message) {
      if (typeof message !== "object" || message === null)
        return "object expected";
      let properties = {};
      if (message.responseName != null && message.hasOwnProperty("responseName")) {
        properties.id = 1;
        if (!$util.isString(message.responseName))
          return "responseName: string expected";
      }
      if (message.index != null && message.hasOwnProperty("index")) {
        if (properties.id === 1)
          return "id: multiple values";
        properties.id = 1;
        if (!$util.isInteger(message.index))
          return "index: integer expected";
      }
      if (message.originalFieldName != null && message.hasOwnProperty("originalFieldName")) {
        if (!$util.isString(message.originalFieldName))
          return "originalFieldName: string expected";
      }
      if (message.type != null && message.hasOwnProperty("type")) {
        if (!$util.isString(message.type))
          return "type: string expected";
      }
      if (message.parentType != null && message.hasOwnProperty("parentType")) {
        if (!$util.isString(message.parentType))
          return "parentType: string expected";
      }
      if (message.cachePolicy != null && message.hasOwnProperty("cachePolicy")) {
        let error = $root.Trace.CachePolicy.verify(message.cachePolicy);
        if (error)
          return "cachePolicy." + error;
      }
      if (message.startTime != null && message.hasOwnProperty("startTime")) {
        if (!$util.isInteger(message.startTime) && !(message.startTime && $util.isInteger(message.startTime.low) && $util.isInteger(message.startTime.high)))
          return "startTime: integer|Long expected";
      }
      if (message.endTime != null && message.hasOwnProperty("endTime")) {
        if (!$util.isInteger(message.endTime) && !(message.endTime && $util.isInteger(message.endTime.low) && $util.isInteger(message.endTime.high)))
          return "endTime: integer|Long expected";
      }
      if (message.error != null && message.hasOwnProperty("error")) {
        if (!Array.isArray(message.error))
          return "error: array expected";
        for (let i = 0; i < message.error.length; ++i) {
          let error = $root.Trace.Error.verify(message.error[i]);
          if (error)
            return "error." + error;
        }
      }
      if (message.child != null && message.hasOwnProperty("child")) {
        if (!Array.isArray(message.child))
          return "child: array expected";
        for (let i = 0; i < message.child.length; ++i) {
          let error = $root.Trace.Node.verify(message.child[i]);
          if (error)
            return "child." + error;
        }
      }
      return null;
    };
    Node.toObject = function toObject(message, options) {
      if (!options)
        options = {};
      let object = {};
      if (options.arrays || options.defaults) {
        object.error = [];
        object.child = [];
      }
      if (options.defaults) {
        object.type = "";
        object.cachePolicy = null;
        object.startTime = 0;
        object.endTime = 0;
        object.parentType = "";
        object.originalFieldName = "";
      }
      if (message.responseName != null && message.hasOwnProperty("responseName")) {
        object.responseName = message.responseName;
        if (options.oneofs)
          object.id = "responseName";
      }
      if (message.index != null && message.hasOwnProperty("index")) {
        object.index = message.index;
        if (options.oneofs)
          object.id = "index";
      }
      if (message.type != null && message.hasOwnProperty("type"))
        object.type = message.type;
      if (message.cachePolicy != null && message.hasOwnProperty("cachePolicy"))
        object.cachePolicy = $root.Trace.CachePolicy.toObject(message.cachePolicy, options);
      if (message.startTime != null && message.hasOwnProperty("startTime"))
        if (typeof message.startTime === "number")
          object.startTime = options.longs === String ? String(message.startTime) : message.startTime;
        else
          object.startTime = options.longs === String ? $util.Long.prototype.toString.call(message.startTime) : options.longs === Number ? new $util.LongBits(message.startTime.low >>> 0, message.startTime.high >>> 0).toNumber(true) : message.startTime;
      if (message.endTime != null && message.hasOwnProperty("endTime"))
        if (typeof message.endTime === "number")
          object.endTime = options.longs === String ? String(message.endTime) : message.endTime;
        else
          object.endTime = options.longs === String ? $util.Long.prototype.toString.call(message.endTime) : options.longs === Number ? new $util.LongBits(message.endTime.low >>> 0, message.endTime.high >>> 0).toNumber(true) : message.endTime;
      if (message.error && message.error.length) {
        object.error = [];
        for (let j = 0; j < message.error.length; ++j)
          object.error[j] = $root.Trace.Error.toObject(message.error[j], options);
      }
      if (message.child && message.child.length) {
        object.child = [];
        for (let j = 0; j < message.child.length; ++j)
          object.child[j] = $root.Trace.Node.toObject(message.child[j], options);
      }
      if (message.parentType != null && message.hasOwnProperty("parentType"))
        object.parentType = message.parentType;
      if (message.originalFieldName != null && message.hasOwnProperty("originalFieldName"))
        object.originalFieldName = message.originalFieldName;
      return object;
    };
    Node.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };
    return Node;
  })();
  Trace2.QueryPlanNode = (function() {
    function QueryPlanNode(properties) {
      if (properties) {
        for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
          if (properties[keys[i]] != null)
            this[keys[i]] = properties[keys[i]];
      }
    }
    QueryPlanNode.prototype.sequence = null;
    QueryPlanNode.prototype.parallel = null;
    QueryPlanNode.prototype.fetch = null;
    QueryPlanNode.prototype.flatten = null;
    QueryPlanNode.prototype.defer = null;
    QueryPlanNode.prototype.condition = null;
    let $oneOfFields;
    Object.defineProperty(QueryPlanNode.prototype, "node", {
      get: $util.oneOfGetter($oneOfFields = ["sequence", "parallel", "fetch", "flatten", "defer", "condition"]),
      set: $util.oneOfSetter($oneOfFields)
    });
    QueryPlanNode.create = function create(properties) {
      return new QueryPlanNode(properties);
    };
    QueryPlanNode.encode = function encode(message, writer) {
      if (!writer)
        writer = $Writer.create();
      if (message.sequence != null && Object.hasOwnProperty.call(message, "sequence"))
        $root.Trace.QueryPlanNode.SequenceNode.encode(message.sequence, writer.uint32(
          /* id 1, wireType 2 =*/
          10
        ).fork()).ldelim();
      if (message.parallel != null && Object.hasOwnProperty.call(message, "parallel"))
        $root.Trace.QueryPlanNode.ParallelNode.encode(message.parallel, writer.uint32(
          /* id 2, wireType 2 =*/
          18
        ).fork()).ldelim();
      if (message.fetch != null && Object.hasOwnProperty.call(message, "fetch"))
        $root.Trace.QueryPlanNode.FetchNode.encode(message.fetch, writer.uint32(
          /* id 3, wireType 2 =*/
          26
        ).fork()).ldelim();
      if (message.flatten != null && Object.hasOwnProperty.call(message, "flatten"))
        $root.Trace.QueryPlanNode.FlattenNode.encode(message.flatten, writer.uint32(
          /* id 4, wireType 2 =*/
          34
        ).fork()).ldelim();
      if (message.defer != null && Object.hasOwnProperty.call(message, "defer"))
        $root.Trace.QueryPlanNode.DeferNode.encode(message.defer, writer.uint32(
          /* id 5, wireType 2 =*/
          42
        ).fork()).ldelim();
      if (message.condition != null && Object.hasOwnProperty.call(message, "condition"))
        $root.Trace.QueryPlanNode.ConditionNode.encode(message.condition, writer.uint32(
          /* id 6, wireType 2 =*/
          50
        ).fork()).ldelim();
      return writer;
    };
    QueryPlanNode.encodeDelimited = function encodeDelimited(message, writer) {
      return this.encode(message, writer).ldelim();
    };
    QueryPlanNode.decode = function decode(reader, length) {
      if (!(reader instanceof $Reader))
        reader = $Reader.create(reader);
      let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.QueryPlanNode();
      while (reader.pos < end) {
        let tag = reader.uint32();
        switch (tag >>> 3) {
          case 1:
            message.sequence = $root.Trace.QueryPlanNode.SequenceNode.decode(reader, reader.uint32());
            break;
          case 2:
            message.parallel = $root.Trace.QueryPlanNode.ParallelNode.decode(reader, reader.uint32());
            break;
          case 3:
            message.fetch = $root.Trace.QueryPlanNode.FetchNode.decode(reader, reader.uint32());
            break;
          case 4:
            message.flatten = $root.Trace.QueryPlanNode.FlattenNode.decode(reader, reader.uint32());
            break;
          case 5:
            message.defer = $root.Trace.QueryPlanNode.DeferNode.decode(reader, reader.uint32());
            break;
          case 6:
            message.condition = $root.Trace.QueryPlanNode.ConditionNode.decode(reader, reader.uint32());
            break;
          default:
            reader.skipType(tag & 7);
            break;
        }
      }
      return message;
    };
    QueryPlanNode.decodeDelimited = function decodeDelimited(reader) {
      if (!(reader instanceof $Reader))
        reader = new $Reader(reader);
      return this.decode(reader, reader.uint32());
    };
    QueryPlanNode.verify = function verify(message) {
      if (typeof message !== "object" || message === null)
        return "object expected";
      let properties = {};
      if (message.sequence != null && message.hasOwnProperty("sequence")) {
        properties.node = 1;
        {
          let error = $root.Trace.QueryPlanNode.SequenceNode.verify(message.sequence);
          if (error)
            return "sequence." + error;
        }
      }
      if (message.parallel != null && message.hasOwnProperty("parallel")) {
        if (properties.node === 1)
          return "node: multiple values";
        properties.node = 1;
        {
          let error = $root.Trace.QueryPlanNode.ParallelNode.verify(message.parallel);
          if (error)
            return "parallel." + error;
        }
      }
      if (message.fetch != null && message.hasOwnProperty("fetch")) {
        if (properties.node === 1)
          return "node: multiple values";
        properties.node = 1;
        {
          let error = $root.Trace.QueryPlanNode.FetchNode.verify(message.fetch);
          if (error)
            return "fetch." + error;
        }
      }
      if (message.flatten != null && message.hasOwnProperty("flatten")) {
        if (properties.node === 1)
          return "node: multiple values";
        properties.node = 1;
        {
          let error = $root.Trace.QueryPlanNode.FlattenNode.verify(message.flatten);
          if (error)
            return "flatten." + error;
        }
      }
      if (message.defer != null && message.hasOwnProperty("defer")) {
        if (properties.node === 1)
          return "node: multiple values";
        properties.node = 1;
        {
          let error = $root.Trace.QueryPlanNode.DeferNode.verify(message.defer);
          if (error)
            return "defer." + error;
        }
      }
      if (message.condition != null && message.hasOwnProperty("condition")) {
        if (properties.node === 1)
          return "node: multiple values";
        properties.node = 1;
        {
          let error = $root.Trace.QueryPlanNode.ConditionNode.verify(message.condition);
          if (error)
            return "condition." + error;
        }
      }
      return null;
    };
    QueryPlanNode.toObject = function toObject(message, options) {
      if (!options)
        options = {};
      let object = {};
      if (message.sequence != null && message.hasOwnProperty("sequence")) {
        object.sequence = $root.Trace.QueryPlanNode.SequenceNode.toObject(message.sequence, options);
        if (options.oneofs)
          object.node = "sequence";
      }
      if (message.parallel != null && message.hasOwnProperty("parallel")) {
        object.parallel = $root.Trace.QueryPlanNode.ParallelNode.toObject(message.parallel, options);
        if (options.oneofs)
          object.node = "parallel";
      }
      if (message.fetch != null && message.hasOwnProperty("fetch")) {
        object.fetch = $root.Trace.QueryPlanNode.FetchNode.toObject(message.fetch, options);
        if (options.oneofs)
          object.node = "fetch";
      }
      if (message.flatten != null && message.hasOwnProperty("flatten")) {
        object.flatten = $root.Trace.QueryPlanNode.FlattenNode.toObject(message.flatten, options);
        if (options.oneofs)
          object.node = "flatten";
      }
      if (message.defer != null && message.hasOwnProperty("defer")) {
        object.defer = $root.Trace.QueryPlanNode.DeferNode.toObject(message.defer, options);
        if (options.oneofs)
          object.node = "defer";
      }
      if (message.condition != null && message.hasOwnProperty("condition")) {
        object.condition = $root.Trace.QueryPlanNode.ConditionNode.toObject(message.condition, options);
        if (options.oneofs)
          object.node = "condition";
      }
      return object;
    };
    QueryPlanNode.prototype.toJSON = function toJSON() {
      return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
    };
    QueryPlanNode.SequenceNode = (function() {
      function SequenceNode(properties) {
        this.nodes = [];
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      SequenceNode.prototype.nodes = $util.emptyArray;
      SequenceNode.create = function create(properties) {
        return new SequenceNode(properties);
      };
      SequenceNode.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.nodes != null && message.nodes.length)
          for (let i = 0; i < message.nodes.length; ++i)
            $root.Trace.QueryPlanNode.encode(message.nodes[i], writer.uint32(
              /* id 1, wireType 2 =*/
              10
            ).fork()).ldelim();
        return writer;
      };
      SequenceNode.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      SequenceNode.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.QueryPlanNode.SequenceNode();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              if (!(message.nodes && message.nodes.length))
                message.nodes = [];
              message.nodes.push($root.Trace.QueryPlanNode.decode(reader, reader.uint32()));
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      SequenceNode.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      SequenceNode.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        if (message.nodes != null && message.hasOwnProperty("nodes")) {
          if (!Array.isArray(message.nodes))
            return "nodes: array expected";
          for (let i = 0; i < message.nodes.length; ++i) {
            let error = $root.Trace.QueryPlanNode.verify(message.nodes[i]);
            if (error)
              return "nodes." + error;
          }
        }
        return null;
      };
      SequenceNode.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (options.arrays || options.defaults)
          object.nodes = [];
        if (message.nodes && message.nodes.length) {
          object.nodes = [];
          for (let j = 0; j < message.nodes.length; ++j)
            object.nodes[j] = $root.Trace.QueryPlanNode.toObject(message.nodes[j], options);
        }
        return object;
      };
      SequenceNode.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return SequenceNode;
    })();
    QueryPlanNode.ParallelNode = (function() {
      function ParallelNode(properties) {
        this.nodes = [];
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      ParallelNode.prototype.nodes = $util.emptyArray;
      ParallelNode.create = function create(properties) {
        return new ParallelNode(properties);
      };
      ParallelNode.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.nodes != null && message.nodes.length)
          for (let i = 0; i < message.nodes.length; ++i)
            $root.Trace.QueryPlanNode.encode(message.nodes[i], writer.uint32(
              /* id 1, wireType 2 =*/
              10
            ).fork()).ldelim();
        return writer;
      };
      ParallelNode.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      ParallelNode.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.QueryPlanNode.ParallelNode();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              if (!(message.nodes && message.nodes.length))
                message.nodes = [];
              message.nodes.push($root.Trace.QueryPlanNode.decode(reader, reader.uint32()));
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      ParallelNode.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      ParallelNode.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        if (message.nodes != null && message.hasOwnProperty("nodes")) {
          if (!Array.isArray(message.nodes))
            return "nodes: array expected";
          for (let i = 0; i < message.nodes.length; ++i) {
            let error = $root.Trace.QueryPlanNode.verify(message.nodes[i]);
            if (error)
              return "nodes." + error;
          }
        }
        return null;
      };
      ParallelNode.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (options.arrays || options.defaults)
          object.nodes = [];
        if (message.nodes && message.nodes.length) {
          object.nodes = [];
          for (let j = 0; j < message.nodes.length; ++j)
            object.nodes[j] = $root.Trace.QueryPlanNode.toObject(message.nodes[j], options);
        }
        return object;
      };
      ParallelNode.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return ParallelNode;
    })();
    QueryPlanNode.FetchNode = (function() {
      function FetchNode(properties) {
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      FetchNode.prototype.serviceName = "";
      FetchNode.prototype.traceParsingFailed = false;
      FetchNode.prototype.trace = null;
      FetchNode.prototype.sentTimeOffset = 0;
      FetchNode.prototype.sentTime = null;
      FetchNode.prototype.receivedTime = null;
      FetchNode.create = function create(properties) {
        return new FetchNode(properties);
      };
      FetchNode.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.serviceName != null && Object.hasOwnProperty.call(message, "serviceName"))
          writer.uint32(
            /* id 1, wireType 2 =*/
            10
          ).string(message.serviceName);
        if (message.traceParsingFailed != null && Object.hasOwnProperty.call(message, "traceParsingFailed"))
          writer.uint32(
            /* id 2, wireType 0 =*/
            16
          ).bool(message.traceParsingFailed);
        if (message.trace != null && Object.hasOwnProperty.call(message, "trace"))
          $root.Trace.encode(message.trace, writer.uint32(
            /* id 3, wireType 2 =*/
            26
          ).fork()).ldelim();
        if (message.sentTimeOffset != null && Object.hasOwnProperty.call(message, "sentTimeOffset"))
          writer.uint32(
            /* id 4, wireType 0 =*/
            32
          ).uint64(message.sentTimeOffset);
        if (message.sentTime != null && Object.hasOwnProperty.call(message, "sentTime"))
          $root.google.protobuf.Timestamp.encode(message.sentTime, writer.uint32(
            /* id 5, wireType 2 =*/
            42
          ).fork()).ldelim();
        if (message.receivedTime != null && Object.hasOwnProperty.call(message, "receivedTime"))
          $root.google.protobuf.Timestamp.encode(message.receivedTime, writer.uint32(
            /* id 6, wireType 2 =*/
            50
          ).fork()).ldelim();
        return writer;
      };
      FetchNode.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      FetchNode.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.QueryPlanNode.FetchNode();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              message.serviceName = reader.string();
              break;
            case 2:
              message.traceParsingFailed = reader.bool();
              break;
            case 3:
              message.trace = $root.Trace.decode(reader, reader.uint32());
              break;
            case 4:
              message.sentTimeOffset = reader.uint64();
              break;
            case 5:
              message.sentTime = $root.google.protobuf.Timestamp.decode(reader, reader.uint32());
              break;
            case 6:
              message.receivedTime = $root.google.protobuf.Timestamp.decode(reader, reader.uint32());
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      FetchNode.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      FetchNode.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        if (message.serviceName != null && message.hasOwnProperty("serviceName")) {
          if (!$util.isString(message.serviceName))
            return "serviceName: string expected";
        }
        if (message.traceParsingFailed != null && message.hasOwnProperty("traceParsingFailed")) {
          if (typeof message.traceParsingFailed !== "boolean")
            return "traceParsingFailed: boolean expected";
        }
        if (message.trace != null && message.hasOwnProperty("trace")) {
          let error = $root.Trace.verify(message.trace);
          if (error)
            return "trace." + error;
        }
        if (message.sentTimeOffset != null && message.hasOwnProperty("sentTimeOffset")) {
          if (!$util.isInteger(message.sentTimeOffset) && !(message.sentTimeOffset && $util.isInteger(message.sentTimeOffset.low) && $util.isInteger(message.sentTimeOffset.high)))
            return "sentTimeOffset: integer|Long expected";
        }
        if (message.sentTime != null && message.hasOwnProperty("sentTime")) {
          let error = $root.google.protobuf.Timestamp.verify(message.sentTime);
          if (error)
            return "sentTime." + error;
        }
        if (message.receivedTime != null && message.hasOwnProperty("receivedTime")) {
          let error = $root.google.protobuf.Timestamp.verify(message.receivedTime);
          if (error)
            return "receivedTime." + error;
        }
        return null;
      };
      FetchNode.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (options.defaults) {
          object.serviceName = "";
          object.traceParsingFailed = false;
          object.trace = null;
          object.sentTimeOffset = 0;
          object.sentTime = null;
          object.receivedTime = null;
        }
        if (message.serviceName != null && message.hasOwnProperty("serviceName"))
          object.serviceName = message.serviceName;
        if (message.traceParsingFailed != null && message.hasOwnProperty("traceParsingFailed"))
          object.traceParsingFailed = message.traceParsingFailed;
        if (message.trace != null && message.hasOwnProperty("trace"))
          object.trace = $root.Trace.toObject(message.trace, options);
        if (message.sentTimeOffset != null && message.hasOwnProperty("sentTimeOffset"))
          if (typeof message.sentTimeOffset === "number")
            object.sentTimeOffset = options.longs === String ? String(message.sentTimeOffset) : message.sentTimeOffset;
          else
            object.sentTimeOffset = options.longs === String ? $util.Long.prototype.toString.call(message.sentTimeOffset) : options.longs === Number ? new $util.LongBits(message.sentTimeOffset.low >>> 0, message.sentTimeOffset.high >>> 0).toNumber(true) : message.sentTimeOffset;
        if (message.sentTime != null && message.hasOwnProperty("sentTime"))
          object.sentTime = $root.google.protobuf.Timestamp.toObject(message.sentTime, options);
        if (message.receivedTime != null && message.hasOwnProperty("receivedTime"))
          object.receivedTime = $root.google.protobuf.Timestamp.toObject(message.receivedTime, options);
        return object;
      };
      FetchNode.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return FetchNode;
    })();
    QueryPlanNode.FlattenNode = (function() {
      function FlattenNode(properties) {
        this.responsePath = [];
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      FlattenNode.prototype.responsePath = $util.emptyArray;
      FlattenNode.prototype.node = null;
      FlattenNode.create = function create(properties) {
        return new FlattenNode(properties);
      };
      FlattenNode.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.responsePath != null && message.responsePath.length)
          for (let i = 0; i < message.responsePath.length; ++i)
            $root.Trace.QueryPlanNode.ResponsePathElement.encode(message.responsePath[i], writer.uint32(
              /* id 1, wireType 2 =*/
              10
            ).fork()).ldelim();
        if (message.node != null && Object.hasOwnProperty.call(message, "node"))
          $root.Trace.QueryPlanNode.encode(message.node, writer.uint32(
            /* id 2, wireType 2 =*/
            18
          ).fork()).ldelim();
        return writer;
      };
      FlattenNode.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      FlattenNode.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.QueryPlanNode.FlattenNode();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              if (!(message.responsePath && message.responsePath.length))
                message.responsePath = [];
              message.responsePath.push($root.Trace.QueryPlanNode.ResponsePathElement.decode(reader, reader.uint32()));
              break;
            case 2:
              message.node = $root.Trace.QueryPlanNode.decode(reader, reader.uint32());
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      FlattenNode.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      FlattenNode.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        if (message.responsePath != null && message.hasOwnProperty("responsePath")) {
          if (!Array.isArray(message.responsePath))
            return "responsePath: array expected";
          for (let i = 0; i < message.responsePath.length; ++i) {
            let error = $root.Trace.QueryPlanNode.ResponsePathElement.verify(message.responsePath[i]);
            if (error)
              return "responsePath." + error;
          }
        }
        if (message.node != null && message.hasOwnProperty("node")) {
          let error = $root.Trace.QueryPlanNode.verify(message.node);
          if (error)
            return "node." + error;
        }
        return null;
      };
      FlattenNode.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (options.arrays || options.defaults)
          object.responsePath = [];
        if (options.defaults)
          object.node = null;
        if (message.responsePath && message.responsePath.length) {
          object.responsePath = [];
          for (let j = 0; j < message.responsePath.length; ++j)
            object.responsePath[j] = $root.Trace.QueryPlanNode.ResponsePathElement.toObject(message.responsePath[j], options);
        }
        if (message.node != null && message.hasOwnProperty("node"))
          object.node = $root.Trace.QueryPlanNode.toObject(message.node, options);
        return object;
      };
      FlattenNode.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return FlattenNode;
    })();
    QueryPlanNode.DeferNode = (function() {
      function DeferNode(properties) {
        this.deferred = [];
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      DeferNode.prototype.primary = null;
      DeferNode.prototype.deferred = $util.emptyArray;
      DeferNode.create = function create(properties) {
        return new DeferNode(properties);
      };
      DeferNode.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.primary != null && Object.hasOwnProperty.call(message, "primary"))
          $root.Trace.QueryPlanNode.DeferNodePrimary.encode(message.primary, writer.uint32(
            /* id 1, wireType 2 =*/
            10
          ).fork()).ldelim();
        if (message.deferred != null && message.deferred.length)
          for (let i = 0; i < message.deferred.length; ++i)
            $root.Trace.QueryPlanNode.DeferredNode.encode(message.deferred[i], writer.uint32(
              /* id 2, wireType 2 =*/
              18
            ).fork()).ldelim();
        return writer;
      };
      DeferNode.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      DeferNode.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.QueryPlanNode.DeferNode();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              message.primary = $root.Trace.QueryPlanNode.DeferNodePrimary.decode(reader, reader.uint32());
              break;
            case 2:
              if (!(message.deferred && message.deferred.length))
                message.deferred = [];
              message.deferred.push($root.Trace.QueryPlanNode.DeferredNode.decode(reader, reader.uint32()));
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      DeferNode.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      DeferNode.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        if (message.primary != null && message.hasOwnProperty("primary")) {
          let error = $root.Trace.QueryPlanNode.DeferNodePrimary.verify(message.primary);
          if (error)
            return "primary." + error;
        }
        if (message.deferred != null && message.hasOwnProperty("deferred")) {
          if (!Array.isArray(message.deferred))
            return "deferred: array expected";
          for (let i = 0; i < message.deferred.length; ++i) {
            let error = $root.Trace.QueryPlanNode.DeferredNode.verify(message.deferred[i]);
            if (error)
              return "deferred." + error;
          }
        }
        return null;
      };
      DeferNode.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (options.arrays || options.defaults)
          object.deferred = [];
        if (options.defaults)
          object.primary = null;
        if (message.primary != null && message.hasOwnProperty("primary"))
          object.primary = $root.Trace.QueryPlanNode.DeferNodePrimary.toObject(message.primary, options);
        if (message.deferred && message.deferred.length) {
          object.deferred = [];
          for (let j = 0; j < message.deferred.length; ++j)
            object.deferred[j] = $root.Trace.QueryPlanNode.DeferredNode.toObject(message.deferred[j], options);
        }
        return object;
      };
      DeferNode.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return DeferNode;
    })();
    QueryPlanNode.ConditionNode = (function() {
      function ConditionNode(properties) {
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      ConditionNode.prototype.condition = "";
      ConditionNode.prototype.ifClause = null;
      ConditionNode.prototype.elseClause = null;
      ConditionNode.create = function create(properties) {
        return new ConditionNode(properties);
      };
      ConditionNode.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.condition != null && Object.hasOwnProperty.call(message, "condition"))
          writer.uint32(
            /* id 1, wireType 2 =*/
            10
          ).string(message.condition);
        if (message.ifClause != null && Object.hasOwnProperty.call(message, "ifClause"))
          $root.Trace.QueryPlanNode.encode(message.ifClause, writer.uint32(
            /* id 2, wireType 2 =*/
            18
          ).fork()).ldelim();
        if (message.elseClause != null && Object.hasOwnProperty.call(message, "elseClause"))
          $root.Trace.QueryPlanNode.encode(message.elseClause, writer.uint32(
            /* id 3, wireType 2 =*/
            26
          ).fork()).ldelim();
        return writer;
      };
      ConditionNode.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      ConditionNode.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.QueryPlanNode.ConditionNode();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              message.condition = reader.string();
              break;
            case 2:
              message.ifClause = $root.Trace.QueryPlanNode.decode(reader, reader.uint32());
              break;
            case 3:
              message.elseClause = $root.Trace.QueryPlanNode.decode(reader, reader.uint32());
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      ConditionNode.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      ConditionNode.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        if (message.condition != null && message.hasOwnProperty("condition")) {
          if (!$util.isString(message.condition))
            return "condition: string expected";
        }
        if (message.ifClause != null && message.hasOwnProperty("ifClause")) {
          let error = $root.Trace.QueryPlanNode.verify(message.ifClause);
          if (error)
            return "ifClause." + error;
        }
        if (message.elseClause != null && message.hasOwnProperty("elseClause")) {
          let error = $root.Trace.QueryPlanNode.verify(message.elseClause);
          if (error)
            return "elseClause." + error;
        }
        return null;
      };
      ConditionNode.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (options.defaults) {
          object.condition = "";
          object.ifClause = null;
          object.elseClause = null;
        }
        if (message.condition != null && message.hasOwnProperty("condition"))
          object.condition = message.condition;
        if (message.ifClause != null && message.hasOwnProperty("ifClause"))
          object.ifClause = $root.Trace.QueryPlanNode.toObject(message.ifClause, options);
        if (message.elseClause != null && message.hasOwnProperty("elseClause"))
          object.elseClause = $root.Trace.QueryPlanNode.toObject(message.elseClause, options);
        return object;
      };
      ConditionNode.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return ConditionNode;
    })();
    QueryPlanNode.DeferNodePrimary = (function() {
      function DeferNodePrimary(properties) {
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      DeferNodePrimary.prototype.node = null;
      DeferNodePrimary.create = function create(properties) {
        return new DeferNodePrimary(properties);
      };
      DeferNodePrimary.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.node != null && Object.hasOwnProperty.call(message, "node"))
          $root.Trace.QueryPlanNode.encode(message.node, writer.uint32(
            /* id 1, wireType 2 =*/
            10
          ).fork()).ldelim();
        return writer;
      };
      DeferNodePrimary.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      DeferNodePrimary.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.QueryPlanNode.DeferNodePrimary();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              message.node = $root.Trace.QueryPlanNode.decode(reader, reader.uint32());
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      DeferNodePrimary.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      DeferNodePrimary.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        if (message.node != null && message.hasOwnProperty("node")) {
          let error = $root.Trace.QueryPlanNode.verify(message.node);
          if (error)
            return "node." + error;
        }
        return null;
      };
      DeferNodePrimary.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (options.defaults)
          object.node = null;
        if (message.node != null && message.hasOwnProperty("node"))
          object.node = $root.Trace.QueryPlanNode.toObject(message.node, options);
        return object;
      };
      DeferNodePrimary.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return DeferNodePrimary;
    })();
    QueryPlanNode.DeferredNode = (function() {
      function DeferredNode(properties) {
        this.depends = [];
        this.path = [];
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      DeferredNode.prototype.depends = $util.emptyArray;
      DeferredNode.prototype.label = "";
      DeferredNode.prototype.path = $util.emptyArray;
      DeferredNode.prototype.node = null;
      DeferredNode.create = function create(properties) {
        return new DeferredNode(properties);
      };
      DeferredNode.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.depends != null && message.depends.length)
          for (let i = 0; i < message.depends.length; ++i)
            $root.Trace.QueryPlanNode.DeferredNodeDepends.encode(message.depends[i], writer.uint32(
              /* id 1, wireType 2 =*/
              10
            ).fork()).ldelim();
        if (message.label != null && Object.hasOwnProperty.call(message, "label"))
          writer.uint32(
            /* id 2, wireType 2 =*/
            18
          ).string(message.label);
        if (message.path != null && message.path.length)
          for (let i = 0; i < message.path.length; ++i)
            $root.Trace.QueryPlanNode.ResponsePathElement.encode(message.path[i], writer.uint32(
              /* id 3, wireType 2 =*/
              26
            ).fork()).ldelim();
        if (message.node != null && Object.hasOwnProperty.call(message, "node"))
          $root.Trace.QueryPlanNode.encode(message.node, writer.uint32(
            /* id 4, wireType 2 =*/
            34
          ).fork()).ldelim();
        return writer;
      };
      DeferredNode.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      DeferredNode.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.QueryPlanNode.DeferredNode();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              if (!(message.depends && message.depends.length))
                message.depends = [];
              message.depends.push($root.Trace.QueryPlanNode.DeferredNodeDepends.decode(reader, reader.uint32()));
              break;
            case 2:
              message.label = reader.string();
              break;
            case 3:
              if (!(message.path && message.path.length))
                message.path = [];
              message.path.push($root.Trace.QueryPlanNode.ResponsePathElement.decode(reader, reader.uint32()));
              break;
            case 4:
              message.node = $root.Trace.QueryPlanNode.decode(reader, reader.uint32());
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      DeferredNode.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      DeferredNode.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        if (message.depends != null && message.hasOwnProperty("depends")) {
          if (!Array.isArray(message.depends))
            return "depends: array expected";
          for (let i = 0; i < message.depends.length; ++i) {
            let error = $root.Trace.QueryPlanNode.DeferredNodeDepends.verify(message.depends[i]);
            if (error)
              return "depends." + error;
          }
        }
        if (message.label != null && message.hasOwnProperty("label")) {
          if (!$util.isString(message.label))
            return "label: string expected";
        }
        if (message.path != null && message.hasOwnProperty("path")) {
          if (!Array.isArray(message.path))
            return "path: array expected";
          for (let i = 0; i < message.path.length; ++i) {
            let error = $root.Trace.QueryPlanNode.ResponsePathElement.verify(message.path[i]);
            if (error)
              return "path." + error;
          }
        }
        if (message.node != null && message.hasOwnProperty("node")) {
          let error = $root.Trace.QueryPlanNode.verify(message.node);
          if (error)
            return "node." + error;
        }
        return null;
      };
      DeferredNode.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (options.arrays || options.defaults) {
          object.depends = [];
          object.path = [];
        }
        if (options.defaults) {
          object.label = "";
          object.node = null;
        }
        if (message.depends && message.depends.length) {
          object.depends = [];
          for (let j = 0; j < message.depends.length; ++j)
            object.depends[j] = $root.Trace.QueryPlanNode.DeferredNodeDepends.toObject(message.depends[j], options);
        }
        if (message.label != null && message.hasOwnProperty("label"))
          object.label = message.label;
        if (message.path && message.path.length) {
          object.path = [];
          for (let j = 0; j < message.path.length; ++j)
            object.path[j] = $root.Trace.QueryPlanNode.ResponsePathElement.toObject(message.path[j], options);
        }
        if (message.node != null && message.hasOwnProperty("node"))
          object.node = $root.Trace.QueryPlanNode.toObject(message.node, options);
        return object;
      };
      DeferredNode.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return DeferredNode;
    })();
    QueryPlanNode.DeferredNodeDepends = (function() {
      function DeferredNodeDepends(properties) {
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      DeferredNodeDepends.prototype.id = "";
      DeferredNodeDepends.prototype.deferLabel = "";
      DeferredNodeDepends.create = function create(properties) {
        return new DeferredNodeDepends(properties);
      };
      DeferredNodeDepends.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.id != null && Object.hasOwnProperty.call(message, "id"))
          writer.uint32(
            /* id 1, wireType 2 =*/
            10
          ).string(message.id);
        if (message.deferLabel != null && Object.hasOwnProperty.call(message, "deferLabel"))
          writer.uint32(
            /* id 2, wireType 2 =*/
            18
          ).string(message.deferLabel);
        return writer;
      };
      DeferredNodeDepends.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      DeferredNodeDepends.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.QueryPlanNode.DeferredNodeDepends();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              message.id = reader.string();
              break;
            case 2:
              message.deferLabel = reader.string();
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      DeferredNodeDepends.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      DeferredNodeDepends.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        if (message.id != null && message.hasOwnProperty("id")) {
          if (!$util.isString(message.id))
            return "id: string expected";
        }
        if (message.deferLabel != null && message.hasOwnProperty("deferLabel")) {
          if (!$util.isString(message.deferLabel))
            return "deferLabel: string expected";
        }
        return null;
      };
      DeferredNodeDepends.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (options.defaults) {
          object.id = "";
          object.deferLabel = "";
        }
        if (message.id != null && message.hasOwnProperty("id"))
          object.id = message.id;
        if (message.deferLabel != null && message.hasOwnProperty("deferLabel"))
          object.deferLabel = message.deferLabel;
        return object;
      };
      DeferredNodeDepends.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return DeferredNodeDepends;
    })();
    QueryPlanNode.ResponsePathElement = (function() {
      function ResponsePathElement(properties) {
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      ResponsePathElement.prototype.fieldName = "";
      ResponsePathElement.prototype.index = 0;
      let $oneOfFields2;
      Object.defineProperty(ResponsePathElement.prototype, "id", {
        get: $util.oneOfGetter($oneOfFields2 = ["fieldName", "index"]),
        set: $util.oneOfSetter($oneOfFields2)
      });
      ResponsePathElement.create = function create(properties) {
        return new ResponsePathElement(properties);
      };
      ResponsePathElement.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.fieldName != null && Object.hasOwnProperty.call(message, "fieldName"))
          writer.uint32(
            /* id 1, wireType 2 =*/
            10
          ).string(message.fieldName);
        if (message.index != null && Object.hasOwnProperty.call(message, "index"))
          writer.uint32(
            /* id 2, wireType 0 =*/
            16
          ).uint32(message.index);
        return writer;
      };
      ResponsePathElement.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      ResponsePathElement.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Trace.QueryPlanNode.ResponsePathElement();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              message.fieldName = reader.string();
              break;
            case 2:
              message.index = reader.uint32();
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      ResponsePathElement.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      ResponsePathElement.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        let properties = {};
        if (message.fieldName != null && message.hasOwnProperty("fieldName")) {
          properties.id = 1;
          if (!$util.isString(message.fieldName))
            return "fieldName: string expected";
        }
        if (message.index != null && message.hasOwnProperty("index")) {
          if (properties.id === 1)
            return "id: multiple values";
          properties.id = 1;
          if (!$util.isInteger(message.index))
            return "index: integer expected";
        }
        return null;
      };
      ResponsePathElement.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (message.fieldName != null && message.hasOwnProperty("fieldName")) {
          object.fieldName = message.fieldName;
          if (options.oneofs)
            object.id = "fieldName";
        }
        if (message.index != null && message.hasOwnProperty("index")) {
          object.index = message.index;
          if (options.oneofs)
            object.id = "index";
        }
        return object;
      };
      ResponsePathElement.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return ResponsePathElement;
    })();
    return QueryPlanNode;
  })();
  return Trace2;
})();
const ReportHeader = $root.ReportHeader = (() => {
  function ReportHeader2(properties) {
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  ReportHeader2.prototype.graphRef = "";
  ReportHeader2.prototype.hostname = "";
  ReportHeader2.prototype.agentVersion = "";
  ReportHeader2.prototype.serviceVersion = "";
  ReportHeader2.prototype.runtimeVersion = "";
  ReportHeader2.prototype.uname = "";
  ReportHeader2.prototype.executableSchemaId = "";
  ReportHeader2.create = function create(properties) {
    return new ReportHeader2(properties);
  };
  ReportHeader2.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.hostname != null && Object.hasOwnProperty.call(message, "hostname"))
      writer.uint32(
        /* id 5, wireType 2 =*/
        42
      ).string(message.hostname);
    if (message.agentVersion != null && Object.hasOwnProperty.call(message, "agentVersion"))
      writer.uint32(
        /* id 6, wireType 2 =*/
        50
      ).string(message.agentVersion);
    if (message.serviceVersion != null && Object.hasOwnProperty.call(message, "serviceVersion"))
      writer.uint32(
        /* id 7, wireType 2 =*/
        58
      ).string(message.serviceVersion);
    if (message.runtimeVersion != null && Object.hasOwnProperty.call(message, "runtimeVersion"))
      writer.uint32(
        /* id 8, wireType 2 =*/
        66
      ).string(message.runtimeVersion);
    if (message.uname != null && Object.hasOwnProperty.call(message, "uname"))
      writer.uint32(
        /* id 9, wireType 2 =*/
        74
      ).string(message.uname);
    if (message.executableSchemaId != null && Object.hasOwnProperty.call(message, "executableSchemaId"))
      writer.uint32(
        /* id 11, wireType 2 =*/
        90
      ).string(message.executableSchemaId);
    if (message.graphRef != null && Object.hasOwnProperty.call(message, "graphRef"))
      writer.uint32(
        /* id 12, wireType 2 =*/
        98
      ).string(message.graphRef);
    return writer;
  };
  ReportHeader2.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  ReportHeader2.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.ReportHeader();
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 12:
          message.graphRef = reader.string();
          break;
        case 5:
          message.hostname = reader.string();
          break;
        case 6:
          message.agentVersion = reader.string();
          break;
        case 7:
          message.serviceVersion = reader.string();
          break;
        case 8:
          message.runtimeVersion = reader.string();
          break;
        case 9:
          message.uname = reader.string();
          break;
        case 11:
          message.executableSchemaId = reader.string();
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  ReportHeader2.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  ReportHeader2.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.graphRef != null && message.hasOwnProperty("graphRef")) {
      if (!$util.isString(message.graphRef))
        return "graphRef: string expected";
    }
    if (message.hostname != null && message.hasOwnProperty("hostname")) {
      if (!$util.isString(message.hostname))
        return "hostname: string expected";
    }
    if (message.agentVersion != null && message.hasOwnProperty("agentVersion")) {
      if (!$util.isString(message.agentVersion))
        return "agentVersion: string expected";
    }
    if (message.serviceVersion != null && message.hasOwnProperty("serviceVersion")) {
      if (!$util.isString(message.serviceVersion))
        return "serviceVersion: string expected";
    }
    if (message.runtimeVersion != null && message.hasOwnProperty("runtimeVersion")) {
      if (!$util.isString(message.runtimeVersion))
        return "runtimeVersion: string expected";
    }
    if (message.uname != null && message.hasOwnProperty("uname")) {
      if (!$util.isString(message.uname))
        return "uname: string expected";
    }
    if (message.executableSchemaId != null && message.hasOwnProperty("executableSchemaId")) {
      if (!$util.isString(message.executableSchemaId))
        return "executableSchemaId: string expected";
    }
    return null;
  };
  ReportHeader2.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.defaults) {
      object.hostname = "";
      object.agentVersion = "";
      object.serviceVersion = "";
      object.runtimeVersion = "";
      object.uname = "";
      object.executableSchemaId = "";
      object.graphRef = "";
    }
    if (message.hostname != null && message.hasOwnProperty("hostname"))
      object.hostname = message.hostname;
    if (message.agentVersion != null && message.hasOwnProperty("agentVersion"))
      object.agentVersion = message.agentVersion;
    if (message.serviceVersion != null && message.hasOwnProperty("serviceVersion"))
      object.serviceVersion = message.serviceVersion;
    if (message.runtimeVersion != null && message.hasOwnProperty("runtimeVersion"))
      object.runtimeVersion = message.runtimeVersion;
    if (message.uname != null && message.hasOwnProperty("uname"))
      object.uname = message.uname;
    if (message.executableSchemaId != null && message.hasOwnProperty("executableSchemaId"))
      object.executableSchemaId = message.executableSchemaId;
    if (message.graphRef != null && message.hasOwnProperty("graphRef"))
      object.graphRef = message.graphRef;
    return object;
  };
  ReportHeader2.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return ReportHeader2;
})();
$root.PathErrorStats = (() => {
  function PathErrorStats(properties) {
    this.children = {};
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  PathErrorStats.prototype.children = $util.emptyObject;
  PathErrorStats.prototype.errorsCount = 0;
  PathErrorStats.prototype.requestsWithErrorsCount = 0;
  PathErrorStats.create = function create(properties) {
    return new PathErrorStats(properties);
  };
  PathErrorStats.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.children != null && Object.hasOwnProperty.call(message, "children"))
      for (let keys = Object.keys(message.children), i = 0; i < keys.length; ++i) {
        writer.uint32(
          /* id 1, wireType 2 =*/
          10
        ).fork().uint32(
          /* id 1, wireType 2 =*/
          10
        ).string(keys[i]);
        $root.PathErrorStats.encode(message.children[keys[i]], writer.uint32(
          /* id 2, wireType 2 =*/
          18
        ).fork()).ldelim().ldelim();
      }
    if (message.errorsCount != null && Object.hasOwnProperty.call(message, "errorsCount"))
      writer.uint32(
        /* id 4, wireType 0 =*/
        32
      ).uint64(message.errorsCount);
    if (message.requestsWithErrorsCount != null && Object.hasOwnProperty.call(message, "requestsWithErrorsCount"))
      writer.uint32(
        /* id 5, wireType 0 =*/
        40
      ).uint64(message.requestsWithErrorsCount);
    return writer;
  };
  PathErrorStats.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  PathErrorStats.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.PathErrorStats(), key;
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 1:
          reader.skip().pos++;
          if (message.children === $util.emptyObject)
            message.children = {};
          key = reader.string();
          reader.pos++;
          message.children[key] = $root.PathErrorStats.decode(reader, reader.uint32());
          break;
        case 4:
          message.errorsCount = reader.uint64();
          break;
        case 5:
          message.requestsWithErrorsCount = reader.uint64();
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  PathErrorStats.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  PathErrorStats.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.children != null && message.hasOwnProperty("children")) {
      if (!$util.isObject(message.children))
        return "children: object expected";
      let key = Object.keys(message.children);
      for (let i = 0; i < key.length; ++i) {
        let error = $root.PathErrorStats.verify(message.children[key[i]]);
        if (error)
          return "children." + error;
      }
    }
    if (message.errorsCount != null && message.hasOwnProperty("errorsCount")) {
      if (!$util.isInteger(message.errorsCount) && !(message.errorsCount && $util.isInteger(message.errorsCount.low) && $util.isInteger(message.errorsCount.high)))
        return "errorsCount: integer|Long expected";
    }
    if (message.requestsWithErrorsCount != null && message.hasOwnProperty("requestsWithErrorsCount")) {
      if (!$util.isInteger(message.requestsWithErrorsCount) && !(message.requestsWithErrorsCount && $util.isInteger(message.requestsWithErrorsCount.low) && $util.isInteger(message.requestsWithErrorsCount.high)))
        return "requestsWithErrorsCount: integer|Long expected";
    }
    return null;
  };
  PathErrorStats.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.objects || options.defaults)
      object.children = {};
    if (options.defaults) {
      object.errorsCount = 0;
      object.requestsWithErrorsCount = 0;
    }
    let keys2;
    if (message.children && (keys2 = Object.keys(message.children)).length) {
      object.children = {};
      for (let j = 0; j < keys2.length; ++j)
        object.children[keys2[j]] = $root.PathErrorStats.toObject(message.children[keys2[j]], options);
    }
    if (message.errorsCount != null && message.hasOwnProperty("errorsCount"))
      if (typeof message.errorsCount === "number")
        object.errorsCount = options.longs === String ? String(message.errorsCount) : message.errorsCount;
      else
        object.errorsCount = options.longs === String ? $util.Long.prototype.toString.call(message.errorsCount) : options.longs === Number ? new $util.LongBits(message.errorsCount.low >>> 0, message.errorsCount.high >>> 0).toNumber(true) : message.errorsCount;
    if (message.requestsWithErrorsCount != null && message.hasOwnProperty("requestsWithErrorsCount"))
      if (typeof message.requestsWithErrorsCount === "number")
        object.requestsWithErrorsCount = options.longs === String ? String(message.requestsWithErrorsCount) : message.requestsWithErrorsCount;
      else
        object.requestsWithErrorsCount = options.longs === String ? $util.Long.prototype.toString.call(message.requestsWithErrorsCount) : options.longs === Number ? new $util.LongBits(message.requestsWithErrorsCount.low >>> 0, message.requestsWithErrorsCount.high >>> 0).toNumber(true) : message.requestsWithErrorsCount;
    return object;
  };
  PathErrorStats.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return PathErrorStats;
})();
$root.QueryLatencyStats = (() => {
  function QueryLatencyStats(properties) {
    this.latencyCount = [];
    this.cacheLatencyCount = [];
    this.publicCacheTtlCount = [];
    this.privateCacheTtlCount = [];
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  QueryLatencyStats.prototype.latencyCount = $util.emptyArray;
  QueryLatencyStats.prototype.requestCount = 0;
  QueryLatencyStats.prototype.cacheHits = 0;
  QueryLatencyStats.prototype.persistedQueryHits = 0;
  QueryLatencyStats.prototype.persistedQueryMisses = 0;
  QueryLatencyStats.prototype.cacheLatencyCount = $util.emptyArray;
  QueryLatencyStats.prototype.rootErrorStats = null;
  QueryLatencyStats.prototype.requestsWithErrorsCount = 0;
  QueryLatencyStats.prototype.publicCacheTtlCount = $util.emptyArray;
  QueryLatencyStats.prototype.privateCacheTtlCount = $util.emptyArray;
  QueryLatencyStats.prototype.registeredOperationCount = 0;
  QueryLatencyStats.prototype.forbiddenOperationCount = 0;
  QueryLatencyStats.prototype.requestsWithoutFieldInstrumentation = 0;
  QueryLatencyStats.create = function create(properties) {
    return new QueryLatencyStats(properties);
  };
  QueryLatencyStats.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.requestCount != null && Object.hasOwnProperty.call(message, "requestCount"))
      writer.uint32(
        /* id 2, wireType 0 =*/
        16
      ).uint64(message.requestCount);
    if (message.cacheHits != null && Object.hasOwnProperty.call(message, "cacheHits"))
      writer.uint32(
        /* id 3, wireType 0 =*/
        24
      ).uint64(message.cacheHits);
    if (message.persistedQueryHits != null && Object.hasOwnProperty.call(message, "persistedQueryHits"))
      writer.uint32(
        /* id 4, wireType 0 =*/
        32
      ).uint64(message.persistedQueryHits);
    if (message.persistedQueryMisses != null && Object.hasOwnProperty.call(message, "persistedQueryMisses"))
      writer.uint32(
        /* id 5, wireType 0 =*/
        40
      ).uint64(message.persistedQueryMisses);
    if (message.rootErrorStats != null && Object.hasOwnProperty.call(message, "rootErrorStats"))
      $root.PathErrorStats.encode(message.rootErrorStats, writer.uint32(
        /* id 7, wireType 2 =*/
        58
      ).fork()).ldelim();
    if (message.requestsWithErrorsCount != null && Object.hasOwnProperty.call(message, "requestsWithErrorsCount"))
      writer.uint32(
        /* id 8, wireType 0 =*/
        64
      ).uint64(message.requestsWithErrorsCount);
    if (message.registeredOperationCount != null && Object.hasOwnProperty.call(message, "registeredOperationCount"))
      writer.uint32(
        /* id 11, wireType 0 =*/
        88
      ).uint64(message.registeredOperationCount);
    if (message.forbiddenOperationCount != null && Object.hasOwnProperty.call(message, "forbiddenOperationCount"))
      writer.uint32(
        /* id 12, wireType 0 =*/
        96
      ).uint64(message.forbiddenOperationCount);
    let array13;
    if (message.latencyCount != null && message.latencyCount.toArray)
      array13 = message.latencyCount.toArray();
    else
      array13 = message.latencyCount;
    if (array13 != null && array13.length) {
      writer.uint32(
        /* id 13, wireType 2 =*/
        106
      ).fork();
      for (let i = 0; i < array13.length; ++i)
        writer.sint64(array13[i]);
      writer.ldelim();
    }
    let array14;
    if (message.cacheLatencyCount != null && message.cacheLatencyCount.toArray)
      array14 = message.cacheLatencyCount.toArray();
    else
      array14 = message.cacheLatencyCount;
    if (array14 != null && array14.length) {
      writer.uint32(
        /* id 14, wireType 2 =*/
        114
      ).fork();
      for (let i = 0; i < array14.length; ++i)
        writer.sint64(array14[i]);
      writer.ldelim();
    }
    let array15;
    if (message.publicCacheTtlCount != null && message.publicCacheTtlCount.toArray)
      array15 = message.publicCacheTtlCount.toArray();
    else
      array15 = message.publicCacheTtlCount;
    if (array15 != null && array15.length) {
      writer.uint32(
        /* id 15, wireType 2 =*/
        122
      ).fork();
      for (let i = 0; i < array15.length; ++i)
        writer.sint64(array15[i]);
      writer.ldelim();
    }
    let array16;
    if (message.privateCacheTtlCount != null && message.privateCacheTtlCount.toArray)
      array16 = message.privateCacheTtlCount.toArray();
    else
      array16 = message.privateCacheTtlCount;
    if (array16 != null && array16.length) {
      writer.uint32(
        /* id 16, wireType 2 =*/
        130
      ).fork();
      for (let i = 0; i < array16.length; ++i)
        writer.sint64(array16[i]);
      writer.ldelim();
    }
    if (message.requestsWithoutFieldInstrumentation != null && Object.hasOwnProperty.call(message, "requestsWithoutFieldInstrumentation"))
      writer.uint32(
        /* id 17, wireType 0 =*/
        136
      ).uint64(message.requestsWithoutFieldInstrumentation);
    return writer;
  };
  QueryLatencyStats.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  QueryLatencyStats.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.QueryLatencyStats();
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 13:
          if (!(message.latencyCount && message.latencyCount.length))
            message.latencyCount = [];
          if ((tag & 7) === 2) {
            let end2 = reader.uint32() + reader.pos;
            while (reader.pos < end2)
              message.latencyCount.push(reader.sint64());
          } else
            message.latencyCount.push(reader.sint64());
          break;
        case 2:
          message.requestCount = reader.uint64();
          break;
        case 3:
          message.cacheHits = reader.uint64();
          break;
        case 4:
          message.persistedQueryHits = reader.uint64();
          break;
        case 5:
          message.persistedQueryMisses = reader.uint64();
          break;
        case 14:
          if (!(message.cacheLatencyCount && message.cacheLatencyCount.length))
            message.cacheLatencyCount = [];
          if ((tag & 7) === 2) {
            let end2 = reader.uint32() + reader.pos;
            while (reader.pos < end2)
              message.cacheLatencyCount.push(reader.sint64());
          } else
            message.cacheLatencyCount.push(reader.sint64());
          break;
        case 7:
          message.rootErrorStats = $root.PathErrorStats.decode(reader, reader.uint32());
          break;
        case 8:
          message.requestsWithErrorsCount = reader.uint64();
          break;
        case 15:
          if (!(message.publicCacheTtlCount && message.publicCacheTtlCount.length))
            message.publicCacheTtlCount = [];
          if ((tag & 7) === 2) {
            let end2 = reader.uint32() + reader.pos;
            while (reader.pos < end2)
              message.publicCacheTtlCount.push(reader.sint64());
          } else
            message.publicCacheTtlCount.push(reader.sint64());
          break;
        case 16:
          if (!(message.privateCacheTtlCount && message.privateCacheTtlCount.length))
            message.privateCacheTtlCount = [];
          if ((tag & 7) === 2) {
            let end2 = reader.uint32() + reader.pos;
            while (reader.pos < end2)
              message.privateCacheTtlCount.push(reader.sint64());
          } else
            message.privateCacheTtlCount.push(reader.sint64());
          break;
        case 11:
          message.registeredOperationCount = reader.uint64();
          break;
        case 12:
          message.forbiddenOperationCount = reader.uint64();
          break;
        case 17:
          message.requestsWithoutFieldInstrumentation = reader.uint64();
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  QueryLatencyStats.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  QueryLatencyStats.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.latencyCount != null && message.hasOwnProperty("latencyCount")) {
      let array13;
      if (message.latencyCount != null && message.latencyCount.toArray)
        array13 = message.latencyCount.toArray();
      else
        array13 = message.latencyCount;
      if (!Array.isArray(array13))
        return "latencyCount: array expected";
      for (let i = 0; i < array13.length; ++i)
        if (!$util.isInteger(array13[i]) && !(array13[i] && $util.isInteger(array13[i].low) && $util.isInteger(array13[i].high)))
          return "latencyCount: integer|Long[] expected";
    }
    if (message.requestCount != null && message.hasOwnProperty("requestCount")) {
      if (!$util.isInteger(message.requestCount) && !(message.requestCount && $util.isInteger(message.requestCount.low) && $util.isInteger(message.requestCount.high)))
        return "requestCount: integer|Long expected";
    }
    if (message.cacheHits != null && message.hasOwnProperty("cacheHits")) {
      if (!$util.isInteger(message.cacheHits) && !(message.cacheHits && $util.isInteger(message.cacheHits.low) && $util.isInteger(message.cacheHits.high)))
        return "cacheHits: integer|Long expected";
    }
    if (message.persistedQueryHits != null && message.hasOwnProperty("persistedQueryHits")) {
      if (!$util.isInteger(message.persistedQueryHits) && !(message.persistedQueryHits && $util.isInteger(message.persistedQueryHits.low) && $util.isInteger(message.persistedQueryHits.high)))
        return "persistedQueryHits: integer|Long expected";
    }
    if (message.persistedQueryMisses != null && message.hasOwnProperty("persistedQueryMisses")) {
      if (!$util.isInteger(message.persistedQueryMisses) && !(message.persistedQueryMisses && $util.isInteger(message.persistedQueryMisses.low) && $util.isInteger(message.persistedQueryMisses.high)))
        return "persistedQueryMisses: integer|Long expected";
    }
    if (message.cacheLatencyCount != null && message.hasOwnProperty("cacheLatencyCount")) {
      let array14;
      if (message.cacheLatencyCount != null && message.cacheLatencyCount.toArray)
        array14 = message.cacheLatencyCount.toArray();
      else
        array14 = message.cacheLatencyCount;
      if (!Array.isArray(array14))
        return "cacheLatencyCount: array expected";
      for (let i = 0; i < array14.length; ++i)
        if (!$util.isInteger(array14[i]) && !(array14[i] && $util.isInteger(array14[i].low) && $util.isInteger(array14[i].high)))
          return "cacheLatencyCount: integer|Long[] expected";
    }
    if (message.rootErrorStats != null && message.hasOwnProperty("rootErrorStats")) {
      let error = $root.PathErrorStats.verify(message.rootErrorStats);
      if (error)
        return "rootErrorStats." + error;
    }
    if (message.requestsWithErrorsCount != null && message.hasOwnProperty("requestsWithErrorsCount")) {
      if (!$util.isInteger(message.requestsWithErrorsCount) && !(message.requestsWithErrorsCount && $util.isInteger(message.requestsWithErrorsCount.low) && $util.isInteger(message.requestsWithErrorsCount.high)))
        return "requestsWithErrorsCount: integer|Long expected";
    }
    if (message.publicCacheTtlCount != null && message.hasOwnProperty("publicCacheTtlCount")) {
      let array15;
      if (message.publicCacheTtlCount != null && message.publicCacheTtlCount.toArray)
        array15 = message.publicCacheTtlCount.toArray();
      else
        array15 = message.publicCacheTtlCount;
      if (!Array.isArray(array15))
        return "publicCacheTtlCount: array expected";
      for (let i = 0; i < array15.length; ++i)
        if (!$util.isInteger(array15[i]) && !(array15[i] && $util.isInteger(array15[i].low) && $util.isInteger(array15[i].high)))
          return "publicCacheTtlCount: integer|Long[] expected";
    }
    if (message.privateCacheTtlCount != null && message.hasOwnProperty("privateCacheTtlCount")) {
      let array16;
      if (message.privateCacheTtlCount != null && message.privateCacheTtlCount.toArray)
        array16 = message.privateCacheTtlCount.toArray();
      else
        array16 = message.privateCacheTtlCount;
      if (!Array.isArray(array16))
        return "privateCacheTtlCount: array expected";
      for (let i = 0; i < array16.length; ++i)
        if (!$util.isInteger(array16[i]) && !(array16[i] && $util.isInteger(array16[i].low) && $util.isInteger(array16[i].high)))
          return "privateCacheTtlCount: integer|Long[] expected";
    }
    if (message.registeredOperationCount != null && message.hasOwnProperty("registeredOperationCount")) {
      if (!$util.isInteger(message.registeredOperationCount) && !(message.registeredOperationCount && $util.isInteger(message.registeredOperationCount.low) && $util.isInteger(message.registeredOperationCount.high)))
        return "registeredOperationCount: integer|Long expected";
    }
    if (message.forbiddenOperationCount != null && message.hasOwnProperty("forbiddenOperationCount")) {
      if (!$util.isInteger(message.forbiddenOperationCount) && !(message.forbiddenOperationCount && $util.isInteger(message.forbiddenOperationCount.low) && $util.isInteger(message.forbiddenOperationCount.high)))
        return "forbiddenOperationCount: integer|Long expected";
    }
    if (message.requestsWithoutFieldInstrumentation != null && message.hasOwnProperty("requestsWithoutFieldInstrumentation")) {
      if (!$util.isInteger(message.requestsWithoutFieldInstrumentation) && !(message.requestsWithoutFieldInstrumentation && $util.isInteger(message.requestsWithoutFieldInstrumentation.low) && $util.isInteger(message.requestsWithoutFieldInstrumentation.high)))
        return "requestsWithoutFieldInstrumentation: integer|Long expected";
    }
    return null;
  };
  QueryLatencyStats.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.arrays || options.defaults) {
      object.latencyCount = [];
      object.cacheLatencyCount = [];
      object.publicCacheTtlCount = [];
      object.privateCacheTtlCount = [];
    }
    if (options.defaults) {
      object.requestCount = 0;
      object.cacheHits = 0;
      object.persistedQueryHits = 0;
      object.persistedQueryMisses = 0;
      object.rootErrorStats = null;
      object.requestsWithErrorsCount = 0;
      object.registeredOperationCount = 0;
      object.forbiddenOperationCount = 0;
      object.requestsWithoutFieldInstrumentation = 0;
    }
    if (message.requestCount != null && message.hasOwnProperty("requestCount"))
      if (typeof message.requestCount === "number")
        object.requestCount = options.longs === String ? String(message.requestCount) : message.requestCount;
      else
        object.requestCount = options.longs === String ? $util.Long.prototype.toString.call(message.requestCount) : options.longs === Number ? new $util.LongBits(message.requestCount.low >>> 0, message.requestCount.high >>> 0).toNumber(true) : message.requestCount;
    if (message.cacheHits != null && message.hasOwnProperty("cacheHits"))
      if (typeof message.cacheHits === "number")
        object.cacheHits = options.longs === String ? String(message.cacheHits) : message.cacheHits;
      else
        object.cacheHits = options.longs === String ? $util.Long.prototype.toString.call(message.cacheHits) : options.longs === Number ? new $util.LongBits(message.cacheHits.low >>> 0, message.cacheHits.high >>> 0).toNumber(true) : message.cacheHits;
    if (message.persistedQueryHits != null && message.hasOwnProperty("persistedQueryHits"))
      if (typeof message.persistedQueryHits === "number")
        object.persistedQueryHits = options.longs === String ? String(message.persistedQueryHits) : message.persistedQueryHits;
      else
        object.persistedQueryHits = options.longs === String ? $util.Long.prototype.toString.call(message.persistedQueryHits) : options.longs === Number ? new $util.LongBits(message.persistedQueryHits.low >>> 0, message.persistedQueryHits.high >>> 0).toNumber(true) : message.persistedQueryHits;
    if (message.persistedQueryMisses != null && message.hasOwnProperty("persistedQueryMisses"))
      if (typeof message.persistedQueryMisses === "number")
        object.persistedQueryMisses = options.longs === String ? String(message.persistedQueryMisses) : message.persistedQueryMisses;
      else
        object.persistedQueryMisses = options.longs === String ? $util.Long.prototype.toString.call(message.persistedQueryMisses) : options.longs === Number ? new $util.LongBits(message.persistedQueryMisses.low >>> 0, message.persistedQueryMisses.high >>> 0).toNumber(true) : message.persistedQueryMisses;
    if (message.rootErrorStats != null && message.hasOwnProperty("rootErrorStats"))
      object.rootErrorStats = $root.PathErrorStats.toObject(message.rootErrorStats, options);
    if (message.requestsWithErrorsCount != null && message.hasOwnProperty("requestsWithErrorsCount"))
      if (typeof message.requestsWithErrorsCount === "number")
        object.requestsWithErrorsCount = options.longs === String ? String(message.requestsWithErrorsCount) : message.requestsWithErrorsCount;
      else
        object.requestsWithErrorsCount = options.longs === String ? $util.Long.prototype.toString.call(message.requestsWithErrorsCount) : options.longs === Number ? new $util.LongBits(message.requestsWithErrorsCount.low >>> 0, message.requestsWithErrorsCount.high >>> 0).toNumber(true) : message.requestsWithErrorsCount;
    if (message.registeredOperationCount != null && message.hasOwnProperty("registeredOperationCount"))
      if (typeof message.registeredOperationCount === "number")
        object.registeredOperationCount = options.longs === String ? String(message.registeredOperationCount) : message.registeredOperationCount;
      else
        object.registeredOperationCount = options.longs === String ? $util.Long.prototype.toString.call(message.registeredOperationCount) : options.longs === Number ? new $util.LongBits(message.registeredOperationCount.low >>> 0, message.registeredOperationCount.high >>> 0).toNumber(true) : message.registeredOperationCount;
    if (message.forbiddenOperationCount != null && message.hasOwnProperty("forbiddenOperationCount"))
      if (typeof message.forbiddenOperationCount === "number")
        object.forbiddenOperationCount = options.longs === String ? String(message.forbiddenOperationCount) : message.forbiddenOperationCount;
      else
        object.forbiddenOperationCount = options.longs === String ? $util.Long.prototype.toString.call(message.forbiddenOperationCount) : options.longs === Number ? new $util.LongBits(message.forbiddenOperationCount.low >>> 0, message.forbiddenOperationCount.high >>> 0).toNumber(true) : message.forbiddenOperationCount;
    if (message.latencyCount && message.latencyCount.length) {
      object.latencyCount = [];
      for (let j = 0; j < message.latencyCount.length; ++j)
        if (typeof message.latencyCount[j] === "number")
          object.latencyCount[j] = options.longs === String ? String(message.latencyCount[j]) : message.latencyCount[j];
        else
          object.latencyCount[j] = options.longs === String ? $util.Long.prototype.toString.call(message.latencyCount[j]) : options.longs === Number ? new $util.LongBits(message.latencyCount[j].low >>> 0, message.latencyCount[j].high >>> 0).toNumber() : message.latencyCount[j];
    }
    if (message.cacheLatencyCount && message.cacheLatencyCount.length) {
      object.cacheLatencyCount = [];
      for (let j = 0; j < message.cacheLatencyCount.length; ++j)
        if (typeof message.cacheLatencyCount[j] === "number")
          object.cacheLatencyCount[j] = options.longs === String ? String(message.cacheLatencyCount[j]) : message.cacheLatencyCount[j];
        else
          object.cacheLatencyCount[j] = options.longs === String ? $util.Long.prototype.toString.call(message.cacheLatencyCount[j]) : options.longs === Number ? new $util.LongBits(message.cacheLatencyCount[j].low >>> 0, message.cacheLatencyCount[j].high >>> 0).toNumber() : message.cacheLatencyCount[j];
    }
    if (message.publicCacheTtlCount && message.publicCacheTtlCount.length) {
      object.publicCacheTtlCount = [];
      for (let j = 0; j < message.publicCacheTtlCount.length; ++j)
        if (typeof message.publicCacheTtlCount[j] === "number")
          object.publicCacheTtlCount[j] = options.longs === String ? String(message.publicCacheTtlCount[j]) : message.publicCacheTtlCount[j];
        else
          object.publicCacheTtlCount[j] = options.longs === String ? $util.Long.prototype.toString.call(message.publicCacheTtlCount[j]) : options.longs === Number ? new $util.LongBits(message.publicCacheTtlCount[j].low >>> 0, message.publicCacheTtlCount[j].high >>> 0).toNumber() : message.publicCacheTtlCount[j];
    }
    if (message.privateCacheTtlCount && message.privateCacheTtlCount.length) {
      object.privateCacheTtlCount = [];
      for (let j = 0; j < message.privateCacheTtlCount.length; ++j)
        if (typeof message.privateCacheTtlCount[j] === "number")
          object.privateCacheTtlCount[j] = options.longs === String ? String(message.privateCacheTtlCount[j]) : message.privateCacheTtlCount[j];
        else
          object.privateCacheTtlCount[j] = options.longs === String ? $util.Long.prototype.toString.call(message.privateCacheTtlCount[j]) : options.longs === Number ? new $util.LongBits(message.privateCacheTtlCount[j].low >>> 0, message.privateCacheTtlCount[j].high >>> 0).toNumber() : message.privateCacheTtlCount[j];
    }
    if (message.requestsWithoutFieldInstrumentation != null && message.hasOwnProperty("requestsWithoutFieldInstrumentation"))
      if (typeof message.requestsWithoutFieldInstrumentation === "number")
        object.requestsWithoutFieldInstrumentation = options.longs === String ? String(message.requestsWithoutFieldInstrumentation) : message.requestsWithoutFieldInstrumentation;
      else
        object.requestsWithoutFieldInstrumentation = options.longs === String ? $util.Long.prototype.toString.call(message.requestsWithoutFieldInstrumentation) : options.longs === Number ? new $util.LongBits(message.requestsWithoutFieldInstrumentation.low >>> 0, message.requestsWithoutFieldInstrumentation.high >>> 0).toNumber(true) : message.requestsWithoutFieldInstrumentation;
    return object;
  };
  QueryLatencyStats.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return QueryLatencyStats;
})();
$root.StatsContext = (() => {
  function StatsContext(properties) {
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  StatsContext.prototype.clientName = "";
  StatsContext.prototype.clientVersion = "";
  StatsContext.create = function create(properties) {
    return new StatsContext(properties);
  };
  StatsContext.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.clientName != null && Object.hasOwnProperty.call(message, "clientName"))
      writer.uint32(
        /* id 2, wireType 2 =*/
        18
      ).string(message.clientName);
    if (message.clientVersion != null && Object.hasOwnProperty.call(message, "clientVersion"))
      writer.uint32(
        /* id 3, wireType 2 =*/
        26
      ).string(message.clientVersion);
    return writer;
  };
  StatsContext.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  StatsContext.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.StatsContext();
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 2:
          message.clientName = reader.string();
          break;
        case 3:
          message.clientVersion = reader.string();
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  StatsContext.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  StatsContext.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.clientName != null && message.hasOwnProperty("clientName")) {
      if (!$util.isString(message.clientName))
        return "clientName: string expected";
    }
    if (message.clientVersion != null && message.hasOwnProperty("clientVersion")) {
      if (!$util.isString(message.clientVersion))
        return "clientVersion: string expected";
    }
    return null;
  };
  StatsContext.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.defaults) {
      object.clientName = "";
      object.clientVersion = "";
    }
    if (message.clientName != null && message.hasOwnProperty("clientName"))
      object.clientName = message.clientName;
    if (message.clientVersion != null && message.hasOwnProperty("clientVersion"))
      object.clientVersion = message.clientVersion;
    return object;
  };
  StatsContext.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return StatsContext;
})();
$root.ContextualizedQueryLatencyStats = (() => {
  function ContextualizedQueryLatencyStats(properties) {
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  ContextualizedQueryLatencyStats.prototype.queryLatencyStats = null;
  ContextualizedQueryLatencyStats.prototype.context = null;
  ContextualizedQueryLatencyStats.create = function create(properties) {
    return new ContextualizedQueryLatencyStats(properties);
  };
  ContextualizedQueryLatencyStats.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.queryLatencyStats != null && Object.hasOwnProperty.call(message, "queryLatencyStats"))
      $root.QueryLatencyStats.encode(message.queryLatencyStats, writer.uint32(
        /* id 1, wireType 2 =*/
        10
      ).fork()).ldelim();
    if (message.context != null && Object.hasOwnProperty.call(message, "context"))
      $root.StatsContext.encode(message.context, writer.uint32(
        /* id 2, wireType 2 =*/
        18
      ).fork()).ldelim();
    return writer;
  };
  ContextualizedQueryLatencyStats.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  ContextualizedQueryLatencyStats.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.ContextualizedQueryLatencyStats();
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 1:
          message.queryLatencyStats = $root.QueryLatencyStats.decode(reader, reader.uint32());
          break;
        case 2:
          message.context = $root.StatsContext.decode(reader, reader.uint32());
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  ContextualizedQueryLatencyStats.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  ContextualizedQueryLatencyStats.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.queryLatencyStats != null && message.hasOwnProperty("queryLatencyStats")) {
      let error = $root.QueryLatencyStats.verify(message.queryLatencyStats);
      if (error)
        return "queryLatencyStats." + error;
    }
    if (message.context != null && message.hasOwnProperty("context")) {
      let error = $root.StatsContext.verify(message.context);
      if (error)
        return "context." + error;
    }
    return null;
  };
  ContextualizedQueryLatencyStats.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.defaults) {
      object.queryLatencyStats = null;
      object.context = null;
    }
    if (message.queryLatencyStats != null && message.hasOwnProperty("queryLatencyStats"))
      object.queryLatencyStats = $root.QueryLatencyStats.toObject(message.queryLatencyStats, options);
    if (message.context != null && message.hasOwnProperty("context"))
      object.context = $root.StatsContext.toObject(message.context, options);
    return object;
  };
  ContextualizedQueryLatencyStats.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return ContextualizedQueryLatencyStats;
})();
$root.ContextualizedTypeStats = (() => {
  function ContextualizedTypeStats(properties) {
    this.perTypeStat = {};
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  ContextualizedTypeStats.prototype.context = null;
  ContextualizedTypeStats.prototype.perTypeStat = $util.emptyObject;
  ContextualizedTypeStats.create = function create(properties) {
    return new ContextualizedTypeStats(properties);
  };
  ContextualizedTypeStats.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.context != null && Object.hasOwnProperty.call(message, "context"))
      $root.StatsContext.encode(message.context, writer.uint32(
        /* id 1, wireType 2 =*/
        10
      ).fork()).ldelim();
    if (message.perTypeStat != null && Object.hasOwnProperty.call(message, "perTypeStat"))
      for (let keys = Object.keys(message.perTypeStat), i = 0; i < keys.length; ++i) {
        writer.uint32(
          /* id 2, wireType 2 =*/
          18
        ).fork().uint32(
          /* id 1, wireType 2 =*/
          10
        ).string(keys[i]);
        $root.TypeStat.encode(message.perTypeStat[keys[i]], writer.uint32(
          /* id 2, wireType 2 =*/
          18
        ).fork()).ldelim().ldelim();
      }
    return writer;
  };
  ContextualizedTypeStats.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  ContextualizedTypeStats.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.ContextualizedTypeStats(), key;
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 1:
          message.context = $root.StatsContext.decode(reader, reader.uint32());
          break;
        case 2:
          reader.skip().pos++;
          if (message.perTypeStat === $util.emptyObject)
            message.perTypeStat = {};
          key = reader.string();
          reader.pos++;
          message.perTypeStat[key] = $root.TypeStat.decode(reader, reader.uint32());
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  ContextualizedTypeStats.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  ContextualizedTypeStats.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.context != null && message.hasOwnProperty("context")) {
      let error = $root.StatsContext.verify(message.context);
      if (error)
        return "context." + error;
    }
    if (message.perTypeStat != null && message.hasOwnProperty("perTypeStat")) {
      if (!$util.isObject(message.perTypeStat))
        return "perTypeStat: object expected";
      let key = Object.keys(message.perTypeStat);
      for (let i = 0; i < key.length; ++i) {
        let error = $root.TypeStat.verify(message.perTypeStat[key[i]]);
        if (error)
          return "perTypeStat." + error;
      }
    }
    return null;
  };
  ContextualizedTypeStats.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.objects || options.defaults)
      object.perTypeStat = {};
    if (options.defaults)
      object.context = null;
    if (message.context != null && message.hasOwnProperty("context"))
      object.context = $root.StatsContext.toObject(message.context, options);
    let keys2;
    if (message.perTypeStat && (keys2 = Object.keys(message.perTypeStat)).length) {
      object.perTypeStat = {};
      for (let j = 0; j < keys2.length; ++j)
        object.perTypeStat[keys2[j]] = $root.TypeStat.toObject(message.perTypeStat[keys2[j]], options);
    }
    return object;
  };
  ContextualizedTypeStats.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return ContextualizedTypeStats;
})();
$root.FieldStat = (() => {
  function FieldStat(properties) {
    this.latencyCount = [];
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  FieldStat.prototype.returnType = "";
  FieldStat.prototype.errorsCount = 0;
  FieldStat.prototype.observedExecutionCount = 0;
  FieldStat.prototype.estimatedExecutionCount = 0;
  FieldStat.prototype.requestsWithErrorsCount = 0;
  FieldStat.prototype.latencyCount = $util.emptyArray;
  FieldStat.create = function create(properties) {
    return new FieldStat(properties);
  };
  FieldStat.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.returnType != null && Object.hasOwnProperty.call(message, "returnType"))
      writer.uint32(
        /* id 3, wireType 2 =*/
        26
      ).string(message.returnType);
    if (message.errorsCount != null && Object.hasOwnProperty.call(message, "errorsCount"))
      writer.uint32(
        /* id 4, wireType 0 =*/
        32
      ).uint64(message.errorsCount);
    if (message.observedExecutionCount != null && Object.hasOwnProperty.call(message, "observedExecutionCount"))
      writer.uint32(
        /* id 5, wireType 0 =*/
        40
      ).uint64(message.observedExecutionCount);
    if (message.requestsWithErrorsCount != null && Object.hasOwnProperty.call(message, "requestsWithErrorsCount"))
      writer.uint32(
        /* id 6, wireType 0 =*/
        48
      ).uint64(message.requestsWithErrorsCount);
    let array9;
    if (message.latencyCount != null && message.latencyCount.toArray)
      array9 = message.latencyCount.toArray();
    else
      array9 = message.latencyCount;
    if (array9 != null && array9.length) {
      writer.uint32(
        /* id 9, wireType 2 =*/
        74
      ).fork();
      for (let i = 0; i < array9.length; ++i)
        writer.sint64(array9[i]);
      writer.ldelim();
    }
    if (message.estimatedExecutionCount != null && Object.hasOwnProperty.call(message, "estimatedExecutionCount"))
      writer.uint32(
        /* id 10, wireType 0 =*/
        80
      ).uint64(message.estimatedExecutionCount);
    return writer;
  };
  FieldStat.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  FieldStat.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.FieldStat();
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 3:
          message.returnType = reader.string();
          break;
        case 4:
          message.errorsCount = reader.uint64();
          break;
        case 5:
          message.observedExecutionCount = reader.uint64();
          break;
        case 10:
          message.estimatedExecutionCount = reader.uint64();
          break;
        case 6:
          message.requestsWithErrorsCount = reader.uint64();
          break;
        case 9:
          if (!(message.latencyCount && message.latencyCount.length))
            message.latencyCount = [];
          if ((tag & 7) === 2) {
            let end2 = reader.uint32() + reader.pos;
            while (reader.pos < end2)
              message.latencyCount.push(reader.sint64());
          } else
            message.latencyCount.push(reader.sint64());
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  FieldStat.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  FieldStat.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.returnType != null && message.hasOwnProperty("returnType")) {
      if (!$util.isString(message.returnType))
        return "returnType: string expected";
    }
    if (message.errorsCount != null && message.hasOwnProperty("errorsCount")) {
      if (!$util.isInteger(message.errorsCount) && !(message.errorsCount && $util.isInteger(message.errorsCount.low) && $util.isInteger(message.errorsCount.high)))
        return "errorsCount: integer|Long expected";
    }
    if (message.observedExecutionCount != null && message.hasOwnProperty("observedExecutionCount")) {
      if (!$util.isInteger(message.observedExecutionCount) && !(message.observedExecutionCount && $util.isInteger(message.observedExecutionCount.low) && $util.isInteger(message.observedExecutionCount.high)))
        return "observedExecutionCount: integer|Long expected";
    }
    if (message.estimatedExecutionCount != null && message.hasOwnProperty("estimatedExecutionCount")) {
      if (!$util.isInteger(message.estimatedExecutionCount) && !(message.estimatedExecutionCount && $util.isInteger(message.estimatedExecutionCount.low) && $util.isInteger(message.estimatedExecutionCount.high)))
        return "estimatedExecutionCount: integer|Long expected";
    }
    if (message.requestsWithErrorsCount != null && message.hasOwnProperty("requestsWithErrorsCount")) {
      if (!$util.isInteger(message.requestsWithErrorsCount) && !(message.requestsWithErrorsCount && $util.isInteger(message.requestsWithErrorsCount.low) && $util.isInteger(message.requestsWithErrorsCount.high)))
        return "requestsWithErrorsCount: integer|Long expected";
    }
    if (message.latencyCount != null && message.hasOwnProperty("latencyCount")) {
      let array9;
      if (message.latencyCount != null && message.latencyCount.toArray)
        array9 = message.latencyCount.toArray();
      else
        array9 = message.latencyCount;
      if (!Array.isArray(array9))
        return "latencyCount: array expected";
      for (let i = 0; i < array9.length; ++i)
        if (!$util.isInteger(array9[i]) && !(array9[i] && $util.isInteger(array9[i].low) && $util.isInteger(array9[i].high)))
          return "latencyCount: integer|Long[] expected";
    }
    return null;
  };
  FieldStat.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.arrays || options.defaults)
      object.latencyCount = [];
    if (options.defaults) {
      object.returnType = "";
      object.errorsCount = 0;
      object.observedExecutionCount = 0;
      object.requestsWithErrorsCount = 0;
      object.estimatedExecutionCount = 0;
    }
    if (message.returnType != null && message.hasOwnProperty("returnType"))
      object.returnType = message.returnType;
    if (message.errorsCount != null && message.hasOwnProperty("errorsCount"))
      if (typeof message.errorsCount === "number")
        object.errorsCount = options.longs === String ? String(message.errorsCount) : message.errorsCount;
      else
        object.errorsCount = options.longs === String ? $util.Long.prototype.toString.call(message.errorsCount) : options.longs === Number ? new $util.LongBits(message.errorsCount.low >>> 0, message.errorsCount.high >>> 0).toNumber(true) : message.errorsCount;
    if (message.observedExecutionCount != null && message.hasOwnProperty("observedExecutionCount"))
      if (typeof message.observedExecutionCount === "number")
        object.observedExecutionCount = options.longs === String ? String(message.observedExecutionCount) : message.observedExecutionCount;
      else
        object.observedExecutionCount = options.longs === String ? $util.Long.prototype.toString.call(message.observedExecutionCount) : options.longs === Number ? new $util.LongBits(message.observedExecutionCount.low >>> 0, message.observedExecutionCount.high >>> 0).toNumber(true) : message.observedExecutionCount;
    if (message.requestsWithErrorsCount != null && message.hasOwnProperty("requestsWithErrorsCount"))
      if (typeof message.requestsWithErrorsCount === "number")
        object.requestsWithErrorsCount = options.longs === String ? String(message.requestsWithErrorsCount) : message.requestsWithErrorsCount;
      else
        object.requestsWithErrorsCount = options.longs === String ? $util.Long.prototype.toString.call(message.requestsWithErrorsCount) : options.longs === Number ? new $util.LongBits(message.requestsWithErrorsCount.low >>> 0, message.requestsWithErrorsCount.high >>> 0).toNumber(true) : message.requestsWithErrorsCount;
    if (message.latencyCount && message.latencyCount.length) {
      object.latencyCount = [];
      for (let j = 0; j < message.latencyCount.length; ++j)
        if (typeof message.latencyCount[j] === "number")
          object.latencyCount[j] = options.longs === String ? String(message.latencyCount[j]) : message.latencyCount[j];
        else
          object.latencyCount[j] = options.longs === String ? $util.Long.prototype.toString.call(message.latencyCount[j]) : options.longs === Number ? new $util.LongBits(message.latencyCount[j].low >>> 0, message.latencyCount[j].high >>> 0).toNumber() : message.latencyCount[j];
    }
    if (message.estimatedExecutionCount != null && message.hasOwnProperty("estimatedExecutionCount"))
      if (typeof message.estimatedExecutionCount === "number")
        object.estimatedExecutionCount = options.longs === String ? String(message.estimatedExecutionCount) : message.estimatedExecutionCount;
      else
        object.estimatedExecutionCount = options.longs === String ? $util.Long.prototype.toString.call(message.estimatedExecutionCount) : options.longs === Number ? new $util.LongBits(message.estimatedExecutionCount.low >>> 0, message.estimatedExecutionCount.high >>> 0).toNumber(true) : message.estimatedExecutionCount;
    return object;
  };
  FieldStat.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return FieldStat;
})();
$root.TypeStat = (() => {
  function TypeStat(properties) {
    this.perFieldStat = {};
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  TypeStat.prototype.perFieldStat = $util.emptyObject;
  TypeStat.create = function create(properties) {
    return new TypeStat(properties);
  };
  TypeStat.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.perFieldStat != null && Object.hasOwnProperty.call(message, "perFieldStat"))
      for (let keys = Object.keys(message.perFieldStat), i = 0; i < keys.length; ++i) {
        writer.uint32(
          /* id 3, wireType 2 =*/
          26
        ).fork().uint32(
          /* id 1, wireType 2 =*/
          10
        ).string(keys[i]);
        $root.FieldStat.encode(message.perFieldStat[keys[i]], writer.uint32(
          /* id 2, wireType 2 =*/
          18
        ).fork()).ldelim().ldelim();
      }
    return writer;
  };
  TypeStat.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  TypeStat.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.TypeStat(), key;
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 3:
          reader.skip().pos++;
          if (message.perFieldStat === $util.emptyObject)
            message.perFieldStat = {};
          key = reader.string();
          reader.pos++;
          message.perFieldStat[key] = $root.FieldStat.decode(reader, reader.uint32());
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  TypeStat.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  TypeStat.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.perFieldStat != null && message.hasOwnProperty("perFieldStat")) {
      if (!$util.isObject(message.perFieldStat))
        return "perFieldStat: object expected";
      let key = Object.keys(message.perFieldStat);
      for (let i = 0; i < key.length; ++i) {
        let error = $root.FieldStat.verify(message.perFieldStat[key[i]]);
        if (error)
          return "perFieldStat." + error;
      }
    }
    return null;
  };
  TypeStat.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.objects || options.defaults)
      object.perFieldStat = {};
    let keys2;
    if (message.perFieldStat && (keys2 = Object.keys(message.perFieldStat)).length) {
      object.perFieldStat = {};
      for (let j = 0; j < keys2.length; ++j)
        object.perFieldStat[keys2[j]] = $root.FieldStat.toObject(message.perFieldStat[keys2[j]], options);
    }
    return object;
  };
  TypeStat.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return TypeStat;
})();
$root.ReferencedFieldsForType = (() => {
  function ReferencedFieldsForType(properties) {
    this.fieldNames = [];
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  ReferencedFieldsForType.prototype.fieldNames = $util.emptyArray;
  ReferencedFieldsForType.prototype.isInterface = false;
  ReferencedFieldsForType.create = function create(properties) {
    return new ReferencedFieldsForType(properties);
  };
  ReferencedFieldsForType.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.fieldNames != null && message.fieldNames.length)
      for (let i = 0; i < message.fieldNames.length; ++i)
        writer.uint32(
          /* id 1, wireType 2 =*/
          10
        ).string(message.fieldNames[i]);
    if (message.isInterface != null && Object.hasOwnProperty.call(message, "isInterface"))
      writer.uint32(
        /* id 2, wireType 0 =*/
        16
      ).bool(message.isInterface);
    return writer;
  };
  ReferencedFieldsForType.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  ReferencedFieldsForType.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.ReferencedFieldsForType();
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 1:
          if (!(message.fieldNames && message.fieldNames.length))
            message.fieldNames = [];
          message.fieldNames.push(reader.string());
          break;
        case 2:
          message.isInterface = reader.bool();
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  ReferencedFieldsForType.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  ReferencedFieldsForType.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.fieldNames != null && message.hasOwnProperty("fieldNames")) {
      if (!Array.isArray(message.fieldNames))
        return "fieldNames: array expected";
      for (let i = 0; i < message.fieldNames.length; ++i)
        if (!$util.isString(message.fieldNames[i]))
          return "fieldNames: string[] expected";
    }
    if (message.isInterface != null && message.hasOwnProperty("isInterface")) {
      if (typeof message.isInterface !== "boolean")
        return "isInterface: boolean expected";
    }
    return null;
  };
  ReferencedFieldsForType.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.arrays || options.defaults)
      object.fieldNames = [];
    if (options.defaults)
      object.isInterface = false;
    if (message.fieldNames && message.fieldNames.length) {
      object.fieldNames = [];
      for (let j = 0; j < message.fieldNames.length; ++j)
        object.fieldNames[j] = message.fieldNames[j];
    }
    if (message.isInterface != null && message.hasOwnProperty("isInterface"))
      object.isInterface = message.isInterface;
    return object;
  };
  ReferencedFieldsForType.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return ReferencedFieldsForType;
})();
const Report = $root.Report = (() => {
  function Report2(properties) {
    this.tracesPerQuery = {};
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  Report2.prototype.header = null;
  Report2.prototype.tracesPerQuery = $util.emptyObject;
  Report2.prototype.endTime = null;
  Report2.prototype.operationCount = 0;
  Report2.prototype.tracesPreAggregated = false;
  Report2.create = function create(properties) {
    return new Report2(properties);
  };
  Report2.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.header != null && Object.hasOwnProperty.call(message, "header"))
      $root.ReportHeader.encode(message.header, writer.uint32(
        /* id 1, wireType 2 =*/
        10
      ).fork()).ldelim();
    if (message.endTime != null && Object.hasOwnProperty.call(message, "endTime"))
      $root.google.protobuf.Timestamp.encode(message.endTime, writer.uint32(
        /* id 2, wireType 2 =*/
        18
      ).fork()).ldelim();
    if (message.tracesPerQuery != null && Object.hasOwnProperty.call(message, "tracesPerQuery"))
      for (let keys = Object.keys(message.tracesPerQuery), i = 0; i < keys.length; ++i) {
        writer.uint32(
          /* id 5, wireType 2 =*/
          42
        ).fork().uint32(
          /* id 1, wireType 2 =*/
          10
        ).string(keys[i]);
        $root.TracesAndStats.encode(message.tracesPerQuery[keys[i]], writer.uint32(
          /* id 2, wireType 2 =*/
          18
        ).fork()).ldelim().ldelim();
      }
    if (message.operationCount != null && Object.hasOwnProperty.call(message, "operationCount"))
      writer.uint32(
        /* id 6, wireType 0 =*/
        48
      ).uint64(message.operationCount);
    if (message.tracesPreAggregated != null && Object.hasOwnProperty.call(message, "tracesPreAggregated"))
      writer.uint32(
        /* id 7, wireType 0 =*/
        56
      ).bool(message.tracesPreAggregated);
    return writer;
  };
  Report2.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  Report2.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.Report(), key;
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 1:
          message.header = $root.ReportHeader.decode(reader, reader.uint32());
          break;
        case 5:
          reader.skip().pos++;
          if (message.tracesPerQuery === $util.emptyObject)
            message.tracesPerQuery = {};
          key = reader.string();
          reader.pos++;
          message.tracesPerQuery[key] = $root.TracesAndStats.decode(reader, reader.uint32());
          break;
        case 2:
          message.endTime = $root.google.protobuf.Timestamp.decode(reader, reader.uint32());
          break;
        case 6:
          message.operationCount = reader.uint64();
          break;
        case 7:
          message.tracesPreAggregated = reader.bool();
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  Report2.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  Report2.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.header != null && message.hasOwnProperty("header")) {
      let error = $root.ReportHeader.verify(message.header);
      if (error)
        return "header." + error;
    }
    if (message.tracesPerQuery != null && message.hasOwnProperty("tracesPerQuery")) {
      if (!$util.isObject(message.tracesPerQuery))
        return "tracesPerQuery: object expected";
      let key = Object.keys(message.tracesPerQuery);
      for (let i = 0; i < key.length; ++i) {
        let error = $root.TracesAndStats.verify(message.tracesPerQuery[key[i]]);
        if (error)
          return "tracesPerQuery." + error;
      }
    }
    if (message.endTime != null && message.hasOwnProperty("endTime")) {
      let error = $root.google.protobuf.Timestamp.verify(message.endTime);
      if (error)
        return "endTime." + error;
    }
    if (message.operationCount != null && message.hasOwnProperty("operationCount")) {
      if (!$util.isInteger(message.operationCount) && !(message.operationCount && $util.isInteger(message.operationCount.low) && $util.isInteger(message.operationCount.high)))
        return "operationCount: integer|Long expected";
    }
    if (message.tracesPreAggregated != null && message.hasOwnProperty("tracesPreAggregated")) {
      if (typeof message.tracesPreAggregated !== "boolean")
        return "tracesPreAggregated: boolean expected";
    }
    return null;
  };
  Report2.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.objects || options.defaults)
      object.tracesPerQuery = {};
    if (options.defaults) {
      object.header = null;
      object.endTime = null;
      object.operationCount = 0;
      object.tracesPreAggregated = false;
    }
    if (message.header != null && message.hasOwnProperty("header"))
      object.header = $root.ReportHeader.toObject(message.header, options);
    if (message.endTime != null && message.hasOwnProperty("endTime"))
      object.endTime = $root.google.protobuf.Timestamp.toObject(message.endTime, options);
    let keys2;
    if (message.tracesPerQuery && (keys2 = Object.keys(message.tracesPerQuery)).length) {
      object.tracesPerQuery = {};
      for (let j = 0; j < keys2.length; ++j)
        object.tracesPerQuery[keys2[j]] = $root.TracesAndStats.toObject(message.tracesPerQuery[keys2[j]], options);
    }
    if (message.operationCount != null && message.hasOwnProperty("operationCount"))
      if (typeof message.operationCount === "number")
        object.operationCount = options.longs === String ? String(message.operationCount) : message.operationCount;
      else
        object.operationCount = options.longs === String ? $util.Long.prototype.toString.call(message.operationCount) : options.longs === Number ? new $util.LongBits(message.operationCount.low >>> 0, message.operationCount.high >>> 0).toNumber(true) : message.operationCount;
    if (message.tracesPreAggregated != null && message.hasOwnProperty("tracesPreAggregated"))
      object.tracesPreAggregated = message.tracesPreAggregated;
    return object;
  };
  Report2.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return Report2;
})();
$root.ContextualizedStats = (() => {
  function ContextualizedStats(properties) {
    this.perTypeStat = {};
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  ContextualizedStats.prototype.context = null;
  ContextualizedStats.prototype.queryLatencyStats = null;
  ContextualizedStats.prototype.perTypeStat = $util.emptyObject;
  ContextualizedStats.create = function create(properties) {
    return new ContextualizedStats(properties);
  };
  ContextualizedStats.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.context != null && Object.hasOwnProperty.call(message, "context"))
      $root.StatsContext.encode(message.context, writer.uint32(
        /* id 1, wireType 2 =*/
        10
      ).fork()).ldelim();
    if (message.queryLatencyStats != null && Object.hasOwnProperty.call(message, "queryLatencyStats"))
      $root.QueryLatencyStats.encode(message.queryLatencyStats, writer.uint32(
        /* id 2, wireType 2 =*/
        18
      ).fork()).ldelim();
    if (message.perTypeStat != null && Object.hasOwnProperty.call(message, "perTypeStat"))
      for (let keys = Object.keys(message.perTypeStat), i = 0; i < keys.length; ++i) {
        writer.uint32(
          /* id 3, wireType 2 =*/
          26
        ).fork().uint32(
          /* id 1, wireType 2 =*/
          10
        ).string(keys[i]);
        $root.TypeStat.encode(message.perTypeStat[keys[i]], writer.uint32(
          /* id 2, wireType 2 =*/
          18
        ).fork()).ldelim().ldelim();
      }
    return writer;
  };
  ContextualizedStats.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  ContextualizedStats.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.ContextualizedStats(), key;
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 1:
          message.context = $root.StatsContext.decode(reader, reader.uint32());
          break;
        case 2:
          message.queryLatencyStats = $root.QueryLatencyStats.decode(reader, reader.uint32());
          break;
        case 3:
          reader.skip().pos++;
          if (message.perTypeStat === $util.emptyObject)
            message.perTypeStat = {};
          key = reader.string();
          reader.pos++;
          message.perTypeStat[key] = $root.TypeStat.decode(reader, reader.uint32());
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  ContextualizedStats.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  ContextualizedStats.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.context != null && message.hasOwnProperty("context")) {
      let error = $root.StatsContext.verify(message.context);
      if (error)
        return "context." + error;
    }
    if (message.queryLatencyStats != null && message.hasOwnProperty("queryLatencyStats")) {
      let error = $root.QueryLatencyStats.verify(message.queryLatencyStats);
      if (error)
        return "queryLatencyStats." + error;
    }
    if (message.perTypeStat != null && message.hasOwnProperty("perTypeStat")) {
      if (!$util.isObject(message.perTypeStat))
        return "perTypeStat: object expected";
      let key = Object.keys(message.perTypeStat);
      for (let i = 0; i < key.length; ++i) {
        let error = $root.TypeStat.verify(message.perTypeStat[key[i]]);
        if (error)
          return "perTypeStat." + error;
      }
    }
    return null;
  };
  ContextualizedStats.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.objects || options.defaults)
      object.perTypeStat = {};
    if (options.defaults) {
      object.context = null;
      object.queryLatencyStats = null;
    }
    if (message.context != null && message.hasOwnProperty("context"))
      object.context = $root.StatsContext.toObject(message.context, options);
    if (message.queryLatencyStats != null && message.hasOwnProperty("queryLatencyStats"))
      object.queryLatencyStats = $root.QueryLatencyStats.toObject(message.queryLatencyStats, options);
    let keys2;
    if (message.perTypeStat && (keys2 = Object.keys(message.perTypeStat)).length) {
      object.perTypeStat = {};
      for (let j = 0; j < keys2.length; ++j)
        object.perTypeStat[keys2[j]] = $root.TypeStat.toObject(message.perTypeStat[keys2[j]], options);
    }
    return object;
  };
  ContextualizedStats.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return ContextualizedStats;
})();
$root.TracesAndStats = (() => {
  function TracesAndStats(properties) {
    this.trace = [];
    this.statsWithContext = [];
    this.referencedFieldsByType = {};
    this.internalTracesContributingToStats = [];
    if (properties) {
      for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
        if (properties[keys[i]] != null)
          this[keys[i]] = properties[keys[i]];
    }
  }
  TracesAndStats.prototype.trace = $util.emptyArray;
  TracesAndStats.prototype.statsWithContext = $util.emptyArray;
  TracesAndStats.prototype.referencedFieldsByType = $util.emptyObject;
  TracesAndStats.prototype.internalTracesContributingToStats = $util.emptyArray;
  TracesAndStats.create = function create(properties) {
    return new TracesAndStats(properties);
  };
  TracesAndStats.encode = function encode(message, writer) {
    if (!writer)
      writer = $Writer.create();
    if (message.trace != null && message.trace.length)
      for (let i = 0; i < message.trace.length; ++i)
        if (message.trace[i] instanceof Uint8Array) {
          writer.uint32(
            /* id 1, wireType 2 =*/
            10
          );
          writer.bytes(message.trace[i]);
        } else
          $root.Trace.encode(message.trace[i], writer.uint32(
            /* id 1, wireType 2 =*/
            10
          ).fork()).ldelim();
    let array2;
    if (message.statsWithContext != null && message.statsWithContext.toArray)
      array2 = message.statsWithContext.toArray();
    else
      array2 = message.statsWithContext;
    if (array2 != null && array2.length)
      for (let i = 0; i < array2.length; ++i)
        $root.ContextualizedStats.encode(array2[i], writer.uint32(
          /* id 2, wireType 2 =*/
          18
        ).fork()).ldelim();
    if (message.internalTracesContributingToStats != null && message.internalTracesContributingToStats.length)
      for (let i = 0; i < message.internalTracesContributingToStats.length; ++i)
        if (message.internalTracesContributingToStats[i] instanceof Uint8Array) {
          writer.uint32(
            /* id 3, wireType 2 =*/
            26
          );
          writer.bytes(message.internalTracesContributingToStats[i]);
        } else
          $root.Trace.encode(message.internalTracesContributingToStats[i], writer.uint32(
            /* id 3, wireType 2 =*/
            26
          ).fork()).ldelim();
    if (message.referencedFieldsByType != null && Object.hasOwnProperty.call(message, "referencedFieldsByType"))
      for (let keys = Object.keys(message.referencedFieldsByType), i = 0; i < keys.length; ++i) {
        writer.uint32(
          /* id 4, wireType 2 =*/
          34
        ).fork().uint32(
          /* id 1, wireType 2 =*/
          10
        ).string(keys[i]);
        $root.ReferencedFieldsForType.encode(message.referencedFieldsByType[keys[i]], writer.uint32(
          /* id 2, wireType 2 =*/
          18
        ).fork()).ldelim().ldelim();
      }
    return writer;
  };
  TracesAndStats.encodeDelimited = function encodeDelimited(message, writer) {
    return this.encode(message, writer).ldelim();
  };
  TracesAndStats.decode = function decode(reader, length) {
    if (!(reader instanceof $Reader))
      reader = $Reader.create(reader);
    let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.TracesAndStats(), key;
    while (reader.pos < end) {
      let tag = reader.uint32();
      switch (tag >>> 3) {
        case 1:
          if (!(message.trace && message.trace.length))
            message.trace = [];
          message.trace.push($root.Trace.decode(reader, reader.uint32()));
          break;
        case 2:
          if (!(message.statsWithContext && message.statsWithContext.length))
            message.statsWithContext = [];
          message.statsWithContext.push($root.ContextualizedStats.decode(reader, reader.uint32()));
          break;
        case 4:
          reader.skip().pos++;
          if (message.referencedFieldsByType === $util.emptyObject)
            message.referencedFieldsByType = {};
          key = reader.string();
          reader.pos++;
          message.referencedFieldsByType[key] = $root.ReferencedFieldsForType.decode(reader, reader.uint32());
          break;
        case 3:
          if (!(message.internalTracesContributingToStats && message.internalTracesContributingToStats.length))
            message.internalTracesContributingToStats = [];
          message.internalTracesContributingToStats.push($root.Trace.decode(reader, reader.uint32()));
          break;
        default:
          reader.skipType(tag & 7);
          break;
      }
    }
    return message;
  };
  TracesAndStats.decodeDelimited = function decodeDelimited(reader) {
    if (!(reader instanceof $Reader))
      reader = new $Reader(reader);
    return this.decode(reader, reader.uint32());
  };
  TracesAndStats.verify = function verify(message) {
    if (typeof message !== "object" || message === null)
      return "object expected";
    if (message.trace != null && message.hasOwnProperty("trace")) {
      if (!Array.isArray(message.trace))
        return "trace: array expected";
      for (let i = 0; i < message.trace.length; ++i)
        if (!(message.trace[i] instanceof Uint8Array)) {
          let error = $root.Trace.verify(message.trace[i]);
          if (error)
            return "trace." + error;
        }
    }
    if (message.statsWithContext != null && message.hasOwnProperty("statsWithContext")) {
      let array2;
      if (message.statsWithContext != null && message.statsWithContext.toArray)
        array2 = message.statsWithContext.toArray();
      else
        array2 = message.statsWithContext;
      if (!Array.isArray(array2))
        return "statsWithContext: array expected";
      for (let i = 0; i < array2.length; ++i) {
        let error = $root.ContextualizedStats.verify(array2[i]);
        if (error)
          return "statsWithContext." + error;
      }
    }
    if (message.referencedFieldsByType != null && message.hasOwnProperty("referencedFieldsByType")) {
      if (!$util.isObject(message.referencedFieldsByType))
        return "referencedFieldsByType: object expected";
      let key = Object.keys(message.referencedFieldsByType);
      for (let i = 0; i < key.length; ++i) {
        let error = $root.ReferencedFieldsForType.verify(message.referencedFieldsByType[key[i]]);
        if (error)
          return "referencedFieldsByType." + error;
      }
    }
    if (message.internalTracesContributingToStats != null && message.hasOwnProperty("internalTracesContributingToStats")) {
      if (!Array.isArray(message.internalTracesContributingToStats))
        return "internalTracesContributingToStats: array expected";
      for (let i = 0; i < message.internalTracesContributingToStats.length; ++i)
        if (!(message.internalTracesContributingToStats[i] instanceof Uint8Array)) {
          let error = $root.Trace.verify(message.internalTracesContributingToStats[i]);
          if (error)
            return "internalTracesContributingToStats." + error;
        }
    }
    return null;
  };
  TracesAndStats.toObject = function toObject(message, options) {
    if (!options)
      options = {};
    let object = {};
    if (options.arrays || options.defaults) {
      object.trace = [];
      object.statsWithContext = [];
      object.internalTracesContributingToStats = [];
    }
    if (options.objects || options.defaults)
      object.referencedFieldsByType = {};
    if (message.trace && message.trace.length) {
      object.trace = [];
      for (let j = 0; j < message.trace.length; ++j)
        object.trace[j] = $root.Trace.toObject(message.trace[j], options);
    }
    if (message.statsWithContext && message.statsWithContext.length) {
      object.statsWithContext = [];
      for (let j = 0; j < message.statsWithContext.length; ++j)
        object.statsWithContext[j] = $root.ContextualizedStats.toObject(message.statsWithContext[j], options);
    }
    if (message.internalTracesContributingToStats && message.internalTracesContributingToStats.length) {
      object.internalTracesContributingToStats = [];
      for (let j = 0; j < message.internalTracesContributingToStats.length; ++j)
        object.internalTracesContributingToStats[j] = $root.Trace.toObject(message.internalTracesContributingToStats[j], options);
    }
    let keys2;
    if (message.referencedFieldsByType && (keys2 = Object.keys(message.referencedFieldsByType)).length) {
      object.referencedFieldsByType = {};
      for (let j = 0; j < keys2.length; ++j)
        object.referencedFieldsByType[keys2[j]] = $root.ReferencedFieldsForType.toObject(message.referencedFieldsByType[keys2[j]], options);
    }
    return object;
  };
  TracesAndStats.prototype.toJSON = function toJSON() {
    return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
  };
  return TracesAndStats;
})();
const google = $root.google = (() => {
  const google2 = {};
  google2.protobuf = (function() {
    const protobuf = {};
    protobuf.Timestamp = (function() {
      function Timestamp(properties) {
        if (properties) {
          for (let keys = Object.keys(properties), i = 0; i < keys.length; ++i)
            if (properties[keys[i]] != null)
              this[keys[i]] = properties[keys[i]];
        }
      }
      Timestamp.prototype.seconds = 0;
      Timestamp.prototype.nanos = 0;
      Timestamp.create = function create(properties) {
        return new Timestamp(properties);
      };
      Timestamp.encode = function encode(message, writer) {
        if (!writer)
          writer = $Writer.create();
        if (message.seconds != null && Object.hasOwnProperty.call(message, "seconds"))
          writer.uint32(
            /* id 1, wireType 0 =*/
            8
          ).int64(message.seconds);
        if (message.nanos != null && Object.hasOwnProperty.call(message, "nanos"))
          writer.uint32(
            /* id 2, wireType 0 =*/
            16
          ).int32(message.nanos);
        return writer;
      };
      Timestamp.encodeDelimited = function encodeDelimited(message, writer) {
        return this.encode(message, writer).ldelim();
      };
      Timestamp.decode = function decode(reader, length) {
        if (!(reader instanceof $Reader))
          reader = $Reader.create(reader);
        let end = length === void 0 ? reader.len : reader.pos + length, message = new $root.google.protobuf.Timestamp();
        while (reader.pos < end) {
          let tag = reader.uint32();
          switch (tag >>> 3) {
            case 1:
              message.seconds = reader.int64();
              break;
            case 2:
              message.nanos = reader.int32();
              break;
            default:
              reader.skipType(tag & 7);
              break;
          }
        }
        return message;
      };
      Timestamp.decodeDelimited = function decodeDelimited(reader) {
        if (!(reader instanceof $Reader))
          reader = new $Reader(reader);
        return this.decode(reader, reader.uint32());
      };
      Timestamp.verify = function verify(message) {
        if (typeof message !== "object" || message === null)
          return "object expected";
        if (message.seconds != null && message.hasOwnProperty("seconds")) {
          if (!$util.isInteger(message.seconds) && !(message.seconds && $util.isInteger(message.seconds.low) && $util.isInteger(message.seconds.high)))
            return "seconds: integer|Long expected";
        }
        if (message.nanos != null && message.hasOwnProperty("nanos")) {
          if (!$util.isInteger(message.nanos))
            return "nanos: integer expected";
        }
        return null;
      };
      Timestamp.toObject = function toObject(message, options) {
        if (!options)
          options = {};
        let object = {};
        if (options.defaults) {
          object.seconds = 0;
          object.nanos = 0;
        }
        if (message.seconds != null && message.hasOwnProperty("seconds"))
          if (typeof message.seconds === "number")
            object.seconds = options.longs === String ? String(message.seconds) : message.seconds;
          else
            object.seconds = options.longs === String ? $util.Long.prototype.toString.call(message.seconds) : options.longs === Number ? new $util.LongBits(message.seconds.low >>> 0, message.seconds.high >>> 0).toNumber() : message.seconds;
        if (message.nanos != null && message.hasOwnProperty("nanos"))
          object.nanos = message.nanos;
        return object;
      };
      Timestamp.prototype.toJSON = function toJSON() {
        return this.constructor.toObject(this, $protobuf.util.toJSONOptions);
      };
      return Timestamp;
    })();
    return protobuf;
  })();
  return google2;
})();
function internalError(message) {
  return new Error(`[internal apollo-server error] ${message}`);
}
class TraceTreeBuilder {
  constructor(options) {
    this.rootNode = new Trace.Node();
    this.trace = new Trace({
      root: this.rootNode,
      fieldExecutionWeight: 1
    });
    this.stopped = false;
    this.nodes = /* @__PURE__ */ new Map([
      [responsePathAsString(), this.rootNode]
    ]);
    const { sendErrors, maskedBy } = options;
    if (!sendErrors || "masked" in sendErrors) {
      this.transformError = () => new index.GraphQLError("<masked>", {
        extensions: { maskedBy }
      });
    } else if ("transform" in sendErrors) {
      this.transformError = sendErrors.transform;
    } else if ("unmodified" in sendErrors) {
      this.transformError = null;
    } else {
      throw new index.UnreachableCaseError(sendErrors);
    }
  }
  startTiming() {
    if (this.startHrTime) {
      throw internalError("startTiming called twice!");
    }
    if (this.stopped) {
      throw internalError("startTiming called after stopTiming!");
    }
    this.trace.startTime = dateToProtoTimestamp(/* @__PURE__ */ new Date());
    this.startHrTime = process.hrtime();
  }
  stopTiming() {
    if (!this.startHrTime) {
      throw internalError("stopTiming called before startTiming!");
    }
    if (this.stopped) {
      throw internalError("stopTiming called twice!");
    }
    this.trace.durationNs = durationHrTimeToNanos(process.hrtime(this.startHrTime));
    this.trace.endTime = dateToProtoTimestamp(/* @__PURE__ */ new Date());
    this.stopped = true;
  }
  willResolveField(info) {
    if (!this.startHrTime) {
      throw internalError("willResolveField called before startTiming!");
    }
    if (this.stopped) {
      return () => {
      };
    }
    const path = info.path;
    const node = this.newNode(path);
    node.type = info.returnType.toString();
    node.parentType = info.parentType.toString();
    node.startTime = durationHrTimeToNanos(process.hrtime(this.startHrTime));
    if (typeof path.key === "string" && path.key !== info.fieldName) {
      node.originalFieldName = info.fieldName;
    }
    return () => {
      node.endTime = durationHrTimeToNanos(process.hrtime(this.startHrTime));
    };
  }
  didEncounterErrors(errors) {
    errors.forEach((err) => {
      if (err.extensions?.serviceName) {
        return;
      }
      const errorForReporting = this.transformAndNormalizeError(err);
      if (errorForReporting === null) {
        return;
      }
      this.addProtobufError(errorForReporting.path, errorToProtobufError(errorForReporting));
    });
  }
  addProtobufError(path, error) {
    if (!this.startHrTime) {
      throw internalError("addProtobufError called before startTiming!");
    }
    if (this.stopped) {
      throw internalError("addProtobufError called after stopTiming!");
    }
    let node = this.rootNode;
    if (Array.isArray(path)) {
      const specificNode = this.nodes.get(path.join("."));
      if (specificNode) {
        node = specificNode;
      } else {
        const responsePath = responsePathFromArray(path, this.rootNode);
        if (!responsePath) {
          throw internalError("addProtobufError called with invalid path!");
        }
        node = this.newNode(responsePath);
      }
    }
    node.error.push(error);
  }
  newNode(path) {
    const node = new Trace.Node();
    const id = path.key;
    if (typeof id === "number") {
      node.index = id;
    } else {
      node.responseName = id;
    }
    this.nodes.set(responsePathAsString(path), node);
    const parentNode = this.ensureParentNode(path);
    parentNode.child.push(node);
    return node;
  }
  ensureParentNode(path) {
    const parentPath = responsePathAsString(path.prev);
    const parentNode = this.nodes.get(parentPath);
    if (parentNode) {
      return parentNode;
    }
    return this.newNode(path.prev);
  }
  transformAndNormalizeError(err) {
    if (this.transformError) {
      const clonedError = Object.assign(Object.create(Object.getPrototypeOf(err)), err);
      const rewrittenError = this.transformError(clonedError);
      if (rewrittenError === null) {
        return null;
      }
      if (!(rewrittenError instanceof index.GraphQLError)) {
        return err;
      }
      return new index.GraphQLError(rewrittenError.message, {
        nodes: err.nodes,
        source: err.source,
        positions: err.positions,
        path: err.path,
        originalError: err.originalError,
        extensions: rewrittenError.extensions || err.extensions
      });
    }
    return err;
  }
}
function durationHrTimeToNanos(hrtime) {
  return hrtime[0] * 1e9 + hrtime[1];
}
function responsePathAsString(p) {
  if (p === void 0) {
    return "";
  }
  let res = String(p.key);
  while ((p = p.prev) !== void 0) {
    res = `${p.key}.${res}`;
  }
  return res;
}
function responsePathFromArray(path, node) {
  let responsePath;
  let nodePtr = node;
  for (const key of path) {
    nodePtr = nodePtr?.child?.find((child) => child.responseName === key);
    responsePath = {
      key,
      prev: responsePath,
      typename: nodePtr?.type ?? void 0
    };
  }
  return responsePath;
}
function errorToProtobufError(error) {
  return new Trace.Error({
    message: error.message,
    location: (error.locations || []).map(({ line, column }) => new Trace.Location({ line, column })),
    json: JSON.stringify(error)
  });
}
function dateToProtoTimestamp(date) {
  const totalMillis = +date;
  const millis = totalMillis % 1e3;
  return new google.protobuf.Timestamp({
    seconds: (totalMillis - millis) / 1e3,
    nanos: millis * 1e6
  });
}
exports.Report = Report;
exports.ReportHeader = ReportHeader;
exports.Trace = Trace;
exports.TraceTreeBuilder = TraceTreeBuilder;
exports.dateToProtoTimestamp = dateToProtoTimestamp;
